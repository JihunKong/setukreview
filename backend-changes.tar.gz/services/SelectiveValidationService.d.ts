import { ValidationResult } from '../types/validation';
export interface BatchValidationOptions {
    validateAll: boolean;
    selectedCategories?: string[];
    selectedFileIds?: string[];
    skipDuplicateDetection?: boolean;
    enableCrossValidation?: boolean;
    priority?: 'speed' | 'accuracy' | 'balanced';
    maxConcurrency?: number;
}
export interface BatchValidationResult {
    batchId: string;
    sessionId: string;
    status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
    progress: number;
    startedAt: Date;
    completedAt?: Date;
    estimatedCompletionTime?: Date;
    results: Map<string, ValidationResult>;
    summary: {
        totalFiles: number;
        completedFiles: number;
        failedFiles: number;
        totalErrors: number;
        totalWarnings: number;
        totalInfo: number;
        processingTimeSeconds: number;
    };
    options: BatchValidationOptions;
}
export declare class SelectiveValidationService {
    private static instance;
    private sessionManager;
    private batchValidations;
    private activeBatches;
    private constructor();
    static getInstance(): SelectiveValidationService;
    startBatchValidation(sessionId: string, options: BatchValidationOptions): Promise<string>;
    validateCategory(sessionId: string, category: string, options?: Omit<BatchValidationOptions, 'selectedCategories' | 'validateAll'>): Promise<string>;
    validateAll(sessionId: string, options?: Omit<BatchValidationOptions, 'validateAll'>): Promise<string>;
    validateAllFilesSync(sessionId: string): Promise<ValidationResult[]>;
    getBatchResult(batchId: string): BatchValidationResult | null;
    cancelBatchValidation(batchId: string): boolean;
    getSessionBatches(sessionId: string): BatchValidationResult[];
    private processBatchValidation;
    private validateSingleFile;
    private validateSingleFileSync;
    private validateFileContent;
    private getFilesToValidate;
    private chunkArray;
    getCategoryValidationStats(batchId: string): Record<string, {
        totalFiles: number;
        completedFiles: number;
        totalErrors: number;
        totalWarnings: number;
        avgErrorsPerFile: number;
        avgWarningsPerFile: number;
    }>;
    cleanupOldBatches(maxAgeHours?: number): void;
    getServiceStats(): {
        totalBatches: number;
        activeBatches: number;
        completedBatches: number;
        failedBatches: number;
        totalFilesProcessed: number;
        avgProcessingTimePerFile: number;
    };
    private calculateAvgProcessingTime;
}
//# sourceMappingURL=SelectiveValidationService.d.ts.map
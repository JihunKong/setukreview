import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export declare class GrammarValidator extends BaseValidator {
    constructor();
    validate(text: string, _context: ValidationContext): Promise<ValidationError[]>;
    private checkMissingPeriod;
    private checkDoubleSpacing;
    private checkParticleWithParentheses;
    private checkEnglishExpressions;
    private isTitle;
    private isListItem;
    private shouldEndWithPeriod;
    private getCorrectParticle;
    private isIntentionalSpacing;
    private isStructuredData;
    private isNarrativeText;
}
//# sourceMappingURL=GrammarValidator.d.ts.map
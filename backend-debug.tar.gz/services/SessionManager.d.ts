import { FileCategory } from './FileCategoryDetector';
import { ValidationResult } from '../types/validation';
export interface SessionData {
    id: string;
    userId?: string;
    createdAt: Date;
    lastAccessedAt: Date;
    files: Map<string, FileCategory>;
    validationResults: Map<string, ValidationResult>;
    status: 'active' | 'processing' | 'completed' | 'expired';
    metadata: {
        totalFiles: number;
        processedFiles: number;
        totalErrors: number;
        totalWarnings: number;
        estimatedCompletionTime?: Date;
    };
}
export interface BatchValidationOptions {
    validateAll: boolean;
    selectedCategories?: string[];
    skipDuplicateDetection?: boolean;
    enableCrossValidation?: boolean;
}
export interface SessionStats {
    totalSessions: number;
    activeSessions: number;
    averageFilesPerSession: number;
    popularCategories: Record<string, number>;
    processingTime: {
        average: number;
        min: number;
        max: number;
    };
}
export declare class SessionManager {
    private static instance;
    private sessions;
    private readonly SESSION_TIMEOUT;
    private readonly MAX_SESSIONS;
    private readonly MAX_FILES_PER_SESSION;
    private constructor();
    static getInstance(): SessionManager;
    createSession(userId?: string): string;
    addFileToSession(sessionId: string, buffer: Buffer, fileName: string, fileSize: number): Promise<FileCategory>;
    getSession(sessionId: string): SessionData | null;
    getSessionFiles(sessionId: string): FileCategory[];
    getFilesByCategory(sessionId: string, category: string): FileCategory[];
    updateFileStatus(sessionId: string, fileId: string, status: FileCategory['status'], validationId?: string): void;
    addValidationResult(sessionId: string, fileId: string, result: ValidationResult): void;
    getValidationResults(sessionId: string): Map<string, ValidationResult>;
    getFileValidationResult(sessionId: string, fileId: string): ValidationResult | null;
    removeFile(sessionId: string, fileId: string): boolean;
    clearSession(sessionId: string): boolean;
    deleteSession(sessionId: string): boolean;
    getSessionStats(sessionId: string): SessionData['metadata'] & {
        averageFileSize: number;
        categoryDistribution: Record<string, number>;
        statusDistribution: Record<string, number>;
    };
    getSystemStats(): SessionStats;
    getUserSessions(userId: string): SessionData[];
    private cleanupExpiredSessions;
    private cleanupOldestSessions;
    estimateCompletionTime(sessionId: string): Date | null;
    updateFileCategory(sessionId: string, fileId: string, newCategory: FileCategory['category']): boolean;
    getCategorySummary(sessionId: string): Record<string, {
        count: number;
        files: FileCategory[];
        avgConfidence: number;
        status: 'pending' | 'processing' | 'completed' | 'mixed';
    }>;
}
//# sourceMappingURL=SessionManager.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GrammarValidator = void 0;
const BaseValidator_1 = require("./BaseValidator");
class GrammarValidator extends BaseValidator_1.BaseValidator {
    constructor() {
        super('grammar', 'Grammar Validator');
    }
    async validate(text, _context) {
        const errors = [];
        if (!text || this.isOnlyNumbers(text) || this.isDateTime(text)) {
            return errors;
        }
        const normalizedText = text.trim();
        errors.push(...this.checkMissingPeriod(normalizedText, text));
        errors.push(...this.checkDoubleSpacing(normalizedText, text));
        errors.push(...this.checkParticleWithParentheses(normalizedText, text));
        errors.push(...this.checkEnglishExpressions(normalizedText, text));
        return errors;
    }
    checkMissingPeriod(normalizedText, originalText) {
        const errors = [];
        if (normalizedText.length < 20) {
            return errors;
        }
        if (this.isTitle(normalizedText) || this.isListItem(normalizedText)) {
            return errors;
        }
        if (this.isStructuredData(normalizedText)) {
            return errors;
        }
        const endsWithPunctuation = /[.!?。]$/.test(normalizedText);
        if (!endsWithPunctuation && this.shouldEndWithPeriod(normalizedText)) {
            if (this.isNarrativeText(normalizedText)) {
                const error = this.createError('문장의 끝에 마침표가 빠져있습니다', 'missing-period', 'info', originalText, `${normalizedText}.`);
                errors.push(error);
            }
        }
        return errors;
    }
    checkDoubleSpacing(normalizedText, originalText) {
        const errors = [];
        const excessiveSpacePattern = /\s{5,}/g;
        const matches = normalizedText.match(excessiveSpacePattern);
        if (matches) {
            if (this.isIntentionalSpacing(normalizedText)) {
                return errors;
            }
            const spaceCount = matches.reduce((sum, match) => sum + match.length, 0);
            if (spaceCount > 10 || matches.some(match => match.length > 8)) {
                const error = this.createError(`과도한 연속 공백이 발견되었습니다 (${Math.max(...matches.map(m => m.length))}개)`, 'excessive-spacing', 'info', originalText, normalizedText.replace(/\s{5,}/g, ' '));
                errors.push(error);
            }
        }
        return errors;
    }
    checkParticleWithParentheses(normalizedText, originalText) {
        const errors = [];
        const particlePattern = /([가-힣]+)\([^)]*\)\s*([을를])/g;
        let match;
        while ((match = particlePattern.exec(normalizedText)) !== null) {
            const wordBeforeParens = match[1];
            const currentParticle = match[2];
            const correctParticle = this.getCorrectParticle(wordBeforeParens);
            if (correctParticle && correctParticle !== currentParticle) {
                const error = this.createError(`조사 사용이 부적절합니다. "${wordBeforeParens}"에는 "${correctParticle}"이 적절합니다`, 'particle-with-parentheses', 'info', originalText, normalizedText.replace(match[0], `${wordBeforeParens}(${match[0].match(/\(([^)]*)\)/)?.[1] || ''})${correctParticle}`));
                errors.push(error);
            }
        }
        return errors;
    }
    checkEnglishExpressions(normalizedText, originalText) {
        const errors = [];
        const englishExpressions = {
            'feedback': '피드백',
            'workshop': '워크숍',
            'seminar': '세미나',
            'project': '프로젝트',
            'program': '프로그램',
            'portfolio': '포트폴리오',
            'presentation': '발표',
            'report': '보고서',
            'assignment': '과제',
            'homework': '숙제',
            'test': '시험',
            'quiz': '퀴즈',
            'review': '검토, 복습',
            'practice': '연습',
            'training': '훈련',
            'activity': '활동',
            'experience': '경험',
            'interview': '인터뷰',
            'survey': '설문조사',
            'research': '연구',
            'study': '공부, 연구'
        };
        for (const [english, korean] of Object.entries(englishExpressions)) {
            const regex = new RegExp(`\\b${english}\\b`, 'gi');
            if (regex.test(normalizedText)) {
                const error = this.createError(`영어 표현 "${english}"는 한글로 표기하는 것이 권장됩니다`, 'english-expression', 'info', originalText, `"${korean}" 사용 권장`);
                errors.push(error);
            }
        }
        return errors;
    }
    isTitle(text) {
        return text.length < 50 &&
            !text.includes('다') &&
            !text.includes('었') &&
            !text.includes('했') &&
            !/[.!?]/.test(text);
    }
    isListItem(text) {
        return /^[\d\s]*[-•·]\s/.test(text) ||
            /^\d+\.\s/.test(text) ||
            /^[가나다라마바사아자차카타파하]\.\s/.test(text);
    }
    shouldEndWithPeriod(text) {
        const verbEndings = ['다', '었다', '였다', '했다', '됐다', '된다', '한다', '있다', '없다'];
        return verbEndings.some(ending => text.includes(ending));
    }
    getCorrectParticle(word) {
        if (!word)
            return null;
        const lastChar = word.charAt(word.length - 1);
        if (lastChar >= '가' && lastChar <= '힣') {
            const charCode = lastChar.charCodeAt(0) - '가'.charCodeAt(0);
            const hasFinalConsonant = (charCode % 28) !== 0;
            return hasFinalConsonant ? '을' : '를';
        }
        return '을';
    }
    isIntentionalSpacing(text) {
        const tabularPatterns = [
            /\d+\s{3,}\d+/,
            /[가-힣]+\s{3,}[가-힣]+\s{3,}[가-힣]+/,
            /^[\s]{3,}[^\s]/m,
            /[A-Za-z]\s{3,}[A-Za-z]/,
        ];
        const listPatterns = [
            /^\s*[-•·]\s+/m,
            /^\s*\d+\.\s+/m,
            /^\s*[가나다라마]\.\s+/m,
        ];
        const allPatterns = [...tabularPatterns, ...listPatterns];
        return allPatterns.some(pattern => pattern.test(text));
    }
    isStructuredData(text) {
        const structuredPatterns = [
            /\d{4}[-./]\d{1,2}[-./]\d{1,2}/,
            /\d+시\s*\d*분?/,
            /\d+학년\s*\d*반?/,
            /^\s*\d+[.)\s]/,
            /\d+\s*[점명개]$/,
            /^\s*[-•·]\s/,
            /\d+\s*[%℃도]/,
            /[가-힣]+\s*:\s*\d/,
            /\d+\s*\/\s*\d+/,
        ];
        const nonKoreanChars = text.replace(/[가-힣ㄱ-ㅎㅏ-ㅣ]/g, '').length;
        const totalChars = text.length;
        const nonKoreanRatio = totalChars > 0 ? nonKoreanChars / totalChars : 0;
        return structuredPatterns.some(pattern => pattern.test(text)) ||
            nonKoreanRatio > 0.3;
    }
    isNarrativeText(text) {
        const narrativePatterns = [
            /[가-힣]+다\s*$/,
            /[가-힣]+었다\s*$/,
            /[가-힣]+였다\s*$/,
            /[가-힣]+했다\s*$/,
            /[가-힣]+한다\s*$/,
            /[가-힣]+된다\s*$/,
            /[가-힣]+있다\s*$/,
            /[가-힣]+없다\s*$/,
            /[가-힣]+된\s*[가-힣]+/,
            /[가-힣]+하는\s*[가-힣]+/,
        ];
        const hasKoreanText = /[가-힣]/.test(text);
        const hasNarrativePattern = narrativePatterns.some(pattern => pattern.test(text));
        const isLongEnough = text.length > 15;
        const koreanChars = (text.match(/[가-힣]/g) || []).length;
        const hasEnoughKorean = koreanChars > 5;
        return hasKoreanText && hasNarrativePattern && isLongEnough && hasEnoughKorean;
    }
}
exports.GrammarValidator = GrammarValidator;
//# sourceMappingURL=GrammarValidator.js.map
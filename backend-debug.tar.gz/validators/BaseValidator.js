"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseValidator = void 0;
class BaseValidator {
    type;
    name;
    constructor(type, name) {
        this.type = type;
        this.name = name;
    }
    createError(message, rule, severity = 'error', originalText = '', suggestion, confidence) {
        return {
            id: `${this.type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            type: this.type,
            severity,
            message,
            location: {
                sheet: '',
                row: 0,
                column: '',
                cell: ''
            },
            originalText,
            suggestion,
            rule,
            confidence
        };
    }
    isKoreanText(text) {
        const koreanRegex = /[\u1100-\u11FF\u3130-\u318F\uAC00-\uD7AF]/;
        return koreanRegex.test(text);
    }
    isEnglishText(text) {
        const englishRegex = /[A-Za-z]/;
        return englishRegex.test(text);
    }
    hasSpecialCharacters(text) {
        const allowedCharsRegex = /^[\u1100-\u11FF\u3130-\u318F\uAC00-\uD7AFa-zA-Z0-9\s\-(),'.\u00A0]*$/;
        return !allowedCharsRegex.test(text);
    }
    countWords(text) {
        return text.trim().split(/\s+/).filter(word => word.length > 0).length;
    }
    normalizeWhitespace(text) {
        return text.replace(/\s+/g, ' ').trim();
    }
    isOnlyNumbers(text) {
        return /^\d+$/.test(text.trim());
    }
    isDateTime(text) {
        const dateTimePatterns = [
            /^\d{4}-\d{2}-\d{2}$/,
            /^\d{4}\.\d{2}\.\d{2}$/,
            /^\d{4}\/\d{2}\/\d{2}$/,
            /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/
        ];
        return dateTimePatterns.some(pattern => pattern.test(text.trim()));
    }
}
exports.BaseValidator = BaseValidator;
//# sourceMappingURL=BaseValidator.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionManager = void 0;
const uuid_1 = require("uuid");
const FileCategoryDetector_1 = require("./FileCategoryDetector");
class SessionManager {
    static instance;
    sessions = new Map();
    SESSION_TIMEOUT = 2 * 60 * 60 * 1000;
    MAX_SESSIONS = 1000;
    MAX_FILES_PER_SESSION = 50;
    constructor() {
        setInterval(() => {
            this.cleanupExpiredSessions();
        }, 30 * 60 * 1000);
    }
    static getInstance() {
        if (!SessionManager.instance) {
            SessionManager.instance = new SessionManager();
        }
        return SessionManager.instance;
    }
    createSession(userId) {
        if (this.sessions.size >= this.MAX_SESSIONS) {
            this.cleanupOldestSessions(this.MAX_SESSIONS * 0.8);
        }
        const sessionId = (0, uuid_1.v4)();
        const session = {
            id: sessionId,
            userId,
            createdAt: new Date(),
            lastAccessedAt: new Date(),
            files: new Map(),
            validationResults: new Map(),
            status: 'active',
            metadata: {
                totalFiles: 0,
                processedFiles: 0,
                totalErrors: 0,
                totalWarnings: 0
            }
        };
        this.sessions.set(sessionId, session);
        console.log(`📝 Created new session: ${sessionId} ${userId ? `for user ${userId}` : '(anonymous)'}`);
        return sessionId;
    }
    async addFileToSession(sessionId, buffer, fileName, fileSize) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        if (session.files.size >= this.MAX_FILES_PER_SESSION) {
            throw new Error(`Maximum ${this.MAX_FILES_PER_SESSION} files per session exceeded`);
        }
        const detector = new FileCategoryDetector_1.FileCategoryDetector();
        const categoryResult = await detector.detectCategory(buffer, fileName);
        const fileCategory = {
            id: (0, uuid_1.v4)(),
            fileName,
            category: categoryResult.category,
            confidence: categoryResult.confidence,
            uploadedAt: new Date(),
            status: 'pending',
            fileSize,
            metadata: {
                sheetCount: categoryResult.sheetAnalysis.length,
                detectedKeywords: categoryResult.detectedKeywords,
                suggestedAlternatives: categoryResult.suggestedAlternatives,
                buffer: buffer
            }
        };
        session.files.set(fileCategory.id, fileCategory);
        session.metadata.totalFiles = session.files.size;
        session.lastAccessedAt = new Date();
        console.log(`📁 Added file to session ${sessionId}: ${fileName} (${categoryResult.category}, confidence: ${categoryResult.confidence})`);
        return fileCategory;
    }
    getSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (session) {
            session.lastAccessedAt = new Date();
            return session;
        }
        return null;
    }
    getSessionFiles(sessionId) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        return Array.from(session.files.values());
    }
    getFilesByCategory(sessionId, category) {
        const files = this.getSessionFiles(sessionId);
        return files.filter(file => file.category === category);
    }
    updateFileStatus(sessionId, fileId, status, validationId) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        const file = session.files.get(fileId);
        if (!file) {
            throw new Error('File not found in session');
        }
        file.status = status;
        if (validationId) {
            file.validationId = validationId;
        }
        if (status === 'completed' || status === 'failed') {
            if (file.metadata?.buffer) {
                file.metadata.buffer = undefined;
            }
        }
        const processedFiles = Array.from(session.files.values())
            .filter(f => f.status === 'completed' || f.status === 'failed').length;
        session.metadata.processedFiles = processedFiles;
        if (processedFiles === session.metadata.totalFiles) {
            session.status = 'completed';
        }
        else if (processedFiles > 0) {
            session.status = 'processing';
        }
        session.lastAccessedAt = new Date();
    }
    addValidationResult(sessionId, fileId, result) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        session.validationResults.set(fileId, result);
        session.metadata.totalErrors += result.errors.length;
        session.metadata.totalWarnings += result.warnings.length;
        session.lastAccessedAt = new Date();
    }
    getValidationResults(sessionId) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        return new Map(session.validationResults);
    }
    getFileValidationResult(sessionId, fileId) {
        const session = this.getSession(sessionId);
        if (!session) {
            return null;
        }
        return session.validationResults.get(fileId) || null;
    }
    removeFile(sessionId, fileId) {
        const session = this.getSession(sessionId);
        if (!session) {
            return false;
        }
        const removed = session.files.delete(fileId);
        if (removed) {
            session.validationResults.delete(fileId);
            session.metadata.totalFiles = session.files.size;
            session.lastAccessedAt = new Date();
        }
        return removed;
    }
    clearSession(sessionId) {
        const session = this.getSession(sessionId);
        if (!session) {
            return false;
        }
        session.files.clear();
        session.validationResults.clear();
        session.status = 'active';
        session.metadata = {
            totalFiles: 0,
            processedFiles: 0,
            totalErrors: 0,
            totalWarnings: 0
        };
        session.lastAccessedAt = new Date();
        console.log(`🧹 Cleared session: ${sessionId}`);
        return true;
    }
    deleteSession(sessionId) {
        const deleted = this.sessions.delete(sessionId);
        if (deleted) {
            console.log(`🗑️ Deleted session: ${sessionId}`);
        }
        return deleted;
    }
    getSessionStats(sessionId) {
        const session = this.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        const files = Array.from(session.files.values());
        const totalSize = files.reduce((sum, file) => sum + file.fileSize, 0);
        const averageFileSize = files.length > 0 ? totalSize / files.length : 0;
        const categoryDistribution = {};
        files.forEach(file => {
            categoryDistribution[file.category] = (categoryDistribution[file.category] || 0) + 1;
        });
        const statusDistribution = {};
        files.forEach(file => {
            statusDistribution[file.status] = (statusDistribution[file.status] || 0) + 1;
        });
        return {
            ...session.metadata,
            averageFileSize: Math.round(averageFileSize),
            categoryDistribution,
            statusDistribution
        };
    }
    getSystemStats() {
        const now = Date.now();
        const activeSessions = Array.from(this.sessions.values())
            .filter(session => now - session.lastAccessedAt.getTime() < this.SESSION_TIMEOUT);
        const allFiles = Array.from(this.sessions.values())
            .flatMap(session => Array.from(session.files.values()));
        const totalFiles = allFiles.length;
        const averageFilesPerSession = this.sessions.size > 0 ? totalFiles / this.sessions.size : 0;
        const popularCategories = {};
        allFiles.forEach(file => {
            popularCategories[file.category] = (popularCategories[file.category] || 0) + 1;
        });
        const processingTimes = [30, 45, 60, 120, 90];
        const processingTime = {
            average: processingTimes.reduce((sum, time) => sum + time, 0) / processingTimes.length,
            min: Math.min(...processingTimes),
            max: Math.max(...processingTimes)
        };
        return {
            totalSessions: this.sessions.size,
            activeSessions: activeSessions.length,
            averageFilesPerSession: Math.round(averageFilesPerSession * 100) / 100,
            popularCategories,
            processingTime
        };
    }
    getUserSessions(userId) {
        return Array.from(this.sessions.values())
            .filter(session => session.userId === userId)
            .sort((a, b) => b.lastAccessedAt.getTime() - a.lastAccessedAt.getTime());
    }
    cleanupExpiredSessions() {
        const now = Date.now();
        const expiredSessions = [];
        for (const [sessionId, session] of this.sessions.entries()) {
            if (now - session.lastAccessedAt.getTime() > this.SESSION_TIMEOUT) {
                expiredSessions.push(sessionId);
            }
        }
        expiredSessions.forEach(sessionId => {
            this.sessions.delete(sessionId);
        });
        if (expiredSessions.length > 0) {
            console.log(`🧹 Cleaned up ${expiredSessions.length} expired sessions`);
        }
    }
    cleanupOldestSessions(targetCount) {
        if (this.sessions.size <= targetCount)
            return;
        const sessions = Array.from(this.sessions.entries())
            .sort(([, a], [, b]) => a.lastAccessedAt.getTime() - b.lastAccessedAt.getTime());
        const toRemove = this.sessions.size - targetCount;
        const removedSessions = sessions.slice(0, toRemove);
        removedSessions.forEach(([sessionId]) => {
            this.sessions.delete(sessionId);
        });
        console.log(`🧹 Cleaned up ${removedSessions.length} oldest sessions`);
    }
    estimateCompletionTime(sessionId) {
        const session = this.getSession(sessionId);
        if (!session || session.metadata.totalFiles === 0) {
            return null;
        }
        const avgProcessingTimePerFile = 60;
        const remainingFiles = session.metadata.totalFiles - session.metadata.processedFiles;
        const estimatedSeconds = remainingFiles * avgProcessingTimePerFile;
        const completionTime = new Date(Date.now() + estimatedSeconds * 1000);
        session.metadata.estimatedCompletionTime = completionTime;
        return completionTime;
    }
    updateFileCategory(sessionId, fileId, newCategory) {
        const session = this.getSession(sessionId);
        if (!session) {
            return false;
        }
        const file = session.files.get(fileId);
        if (!file) {
            return false;
        }
        const oldCategory = file.category;
        file.category = newCategory;
        file.confidence = 1.0;
        session.lastAccessedAt = new Date();
        console.log(`📝 Updated file category: ${file.fileName} from ${oldCategory} to ${newCategory}`);
        return true;
    }
    getCategorySummary(sessionId) {
        const files = this.getSessionFiles(sessionId);
        const summary = {};
        files.forEach(file => {
            if (!summary[file.category]) {
                summary[file.category] = {
                    count: 0,
                    files: [],
                    totalConfidence: 0
                };
            }
            summary[file.category].count++;
            summary[file.category].files.push(file);
            summary[file.category].totalConfidence += file.confidence;
        });
        Object.keys(summary).forEach(category => {
            const categoryData = summary[category];
            categoryData.avgConfidence = categoryData.totalConfidence / categoryData.count;
            const statuses = categoryData.files.map((f) => f.status);
            const uniqueStatuses = [...new Set(statuses)];
            if (uniqueStatuses.length === 1) {
                categoryData.status = uniqueStatuses[0];
            }
            else {
                categoryData.status = 'mixed';
            }
            delete categoryData.totalConfidence;
        });
        return summary;
    }
}
exports.SessionManager = SessionManager;
//# sourceMappingURL=SessionManager.js.map
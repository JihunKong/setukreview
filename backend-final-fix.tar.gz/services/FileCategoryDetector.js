"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileCategoryDetector = void 0;
const XLSX = __importStar(require("xlsx"));
class FileCategoryDetector {
    CATEGORY_PATTERNS = {
        '출결상황': {
            keywords: ['출결', '결석', '지각', '조퇴', '결과', '무단', '병결', '사고', '출석일수', '수업일수'],
            weight: 1.0,
            synonyms: ['출석부', '출결관리', '출결현황', '출석현황']
        },
        '개인세부능력': {
            keywords: ['세부능력', '특기사항', '교과학습', '발달상황', '성취수준', '학습활동', '수행평가', '과목별'],
            weight: 0.9,
            synonyms: ['개인별특기', '학습상황', '교과발달', '성취도']
        },
        '인적사항': {
            keywords: ['성명', '생년월일', '성별', '주소', '전화번호', '학적번호', '학년', '반', '번호', '보호자'],
            weight: 1.0,
            synonyms: ['개인정보', '학적정보', '기본정보', '학생정보']
        },
        '수상경력': {
            keywords: ['수상', '대회', '상장', '표창', '시상', '우수상', '최우수', '장려상', '입상', '금상', '은상', '동상'],
            weight: 0.8,
            synonyms: ['수상실적', '대회실적', '시상실적', '표창실적']
        },
        '창의적체험활동': {
            keywords: ['창의적', '체험활동', '봉사활동', '동아리', '자율활동', '진로활동', 'CA', '특별활동'],
            weight: 0.9,
            synonyms: ['창체', '체험학습', '특활', '창의활동']
        },
        '독서활동': {
            keywords: ['독서', '도서', '책', '읽기', '서명', '저자', '출판사', '독후감', '책읽기'],
            weight: 0.7,
            synonyms: ['독서현황', '독서실적', '독서기록', '도서목록']
        },
        '행동특성및종합의견': {
            keywords: ['행동특성', '종합의견', '담임', '교사의견', '행동관찰', '성격', '태도', '특징', '관찰내용'],
            weight: 0.8,
            synonyms: ['행특', '담임소견', '종합평가', '행동평가']
        }
    };
    NEIS_STRUCTURE_INDICATORS = [
        '나이스', 'NEIS', '학교생활기록부', '생활기록', '학생부',
        '학급', '학년', '학기', '기준일', '작성일', '출력일'
    ];
    EXCLUDED_SHEET_NAMES = [
        'Sheet1', 'Sheet2', 'Sheet3', '시트1', '시트2', '시트3',
        'summary', '요약', '전체', 'total', '합계'
    ];
    async detectCategory(buffer, fileName) {
        try {
            console.log(`🔍 Detecting category for file: ${fileName}`);
            const workbook = XLSX.read(buffer, { type: 'buffer', cellText: false });
            const excelData = this.convertWorkbookToExcelData(workbook, fileName);
            const analyses = await Promise.all([
                this.analyzeByFileName(fileName),
                this.analyzeBySheetNames(workbook.SheetNames),
                this.analyzeByContent(excelData),
                this.analyzeByStructure(excelData)
            ]);
            const combinedResult = this.combineAnalysisResults(analyses);
            console.log(`✅ Category detected: ${combinedResult.category} (confidence: ${combinedResult.confidence})`);
            return combinedResult;
        }
        catch (error) {
            console.error(`❌ Failed to detect category for ${fileName}:`, error);
            return {
                category: '기타',
                confidence: 0.0,
                detectedKeywords: [],
                sheetAnalysis: [],
                suggestedAlternatives: []
            };
        }
    }
    async analyzeByFileName(fileName) {
        const lowerFileName = fileName.toLowerCase();
        const detectedKeywords = [];
        const scores = {};
        for (const [category, pattern] of Object.entries(this.CATEGORY_PATTERNS)) {
            let score = 0;
            for (const keyword of pattern.keywords) {
                if (lowerFileName.includes(keyword.toLowerCase())) {
                    score += pattern.weight;
                    detectedKeywords.push(keyword);
                }
            }
            for (const synonym of pattern.synonyms) {
                if (lowerFileName.includes(synonym.toLowerCase())) {
                    score += pattern.weight * 0.8;
                    detectedKeywords.push(synonym);
                }
            }
            scores[category] = score;
        }
        const topCategory = Object.entries(scores)
            .sort(([, a], [, b]) => b - a)[0];
        return {
            category: topCategory ? topCategory[0] : '기타',
            confidence: topCategory ? Math.min(topCategory[1] / 3, 1.0) : 0,
            detectedKeywords: detectedKeywords.slice(0, 10)
        };
    }
    async analyzeBySheetNames(sheetNames) {
        const detectedKeywords = [];
        const scores = {};
        const sheetAnalysis = [];
        for (const sheetName of sheetNames) {
            if (this.EXCLUDED_SHEET_NAMES.some(excluded => sheetName.toLowerCase().includes(excluded.toLowerCase()))) {
                continue;
            }
            const analysis = {
                sheetName,
                keywordMatches: [],
                structureScore: 0,
                contentType: 'unknown'
            };
            for (const [category, pattern] of Object.entries(this.CATEGORY_PATTERNS)) {
                for (const keyword of [...pattern.keywords, ...pattern.synonyms]) {
                    if (sheetName.toLowerCase().includes(keyword.toLowerCase())) {
                        const match = {
                            keyword,
                            category,
                            count: 1,
                            positions: [`sheet:${sheetName}`],
                            weight: pattern.weight
                        };
                        analysis.keywordMatches.push(match);
                        detectedKeywords.push(keyword);
                        scores[category] = (scores[category] || 0) + pattern.weight * 1.5;
                    }
                }
            }
            sheetAnalysis.push(analysis);
        }
        const topCategory = Object.entries(scores)
            .sort(([, a], [, b]) => b - a)[0];
        return {
            category: topCategory ? topCategory[0] : '기타',
            confidence: topCategory ? Math.min(topCategory[1] / 5, 1.0) : 0,
            detectedKeywords,
            sheetAnalysis
        };
    }
    async analyzeByContent(excelData) {
        const detectedKeywords = [];
        const scores = {};
        const keywordCounts = {};
        for (const [sheetName, sheet] of Object.entries(excelData.sheets)) {
            const { data } = sheet;
            const sampleRows = data.slice(0, 20);
            for (const row of sampleRows) {
                for (const cell of row) {
                    if (typeof cell === 'string' && cell.length > 0) {
                        const cellText = cell.toLowerCase();
                        for (const [category, pattern] of Object.entries(this.CATEGORY_PATTERNS)) {
                            for (const keyword of [...pattern.keywords, ...pattern.synonyms]) {
                                const keywordLower = keyword.toLowerCase();
                                if (cellText.includes(keywordLower)) {
                                    const count = (cellText.match(new RegExp(keywordLower, 'g')) || []).length;
                                    keywordCounts[keyword] = (keywordCounts[keyword] || 0) + count;
                                    scores[category] = (scores[category] || 0) + (pattern.weight * count);
                                    if (!detectedKeywords.includes(keyword)) {
                                        detectedKeywords.push(keyword);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        const topCategory = Object.entries(scores)
            .sort(([, a], [, b]) => b - a)[0];
        return {
            category: topCategory ? topCategory[0] : '기타',
            confidence: topCategory ? Math.min(topCategory[1] / 10, 1.0) : 0,
            detectedKeywords: detectedKeywords.slice(0, 15)
        };
    }
    async analyzeByStructure(excelData) {
        let neisScore = 0;
        let structuralHints = [];
        const allText = this.extractAllText(excelData).toLowerCase();
        for (const indicator of this.NEIS_STRUCTURE_INDICATORS) {
            if (allText.includes(indicator.toLowerCase())) {
                neisScore += 1;
                structuralHints.push(indicator);
            }
        }
        const hasStudentInfoPattern = this.detectStudentInfoPattern(excelData);
        if (hasStudentInfoPattern) {
            neisScore += 2;
            structuralHints.push('학생정보패턴');
        }
        const datePatterns = this.detectDatePatterns(excelData);
        if (datePatterns.length > 0) {
            neisScore += 1;
            structuralHints.push(...datePatterns);
        }
        return {
            category: neisScore > 3 ? '인적사항' : '기타',
            confidence: Math.min(neisScore / 6, 0.8),
            detectedKeywords: structuralHints
        };
    }
    combineAnalysisResults(analyses) {
        const categoryScores = {};
        const allKeywords = new Set();
        const allSheetAnalysis = [];
        const weights = [0.3, 0.4, 0.25, 0.05];
        analyses.forEach((analysis, index) => {
            if (analysis.category && analysis.category !== '기타') {
                const weight = weights[index];
                const score = (analysis.confidence || 0) * weight;
                categoryScores[analysis.category] = (categoryScores[analysis.category] || 0) + score;
            }
            if (analysis.detectedKeywords) {
                analysis.detectedKeywords.forEach(keyword => allKeywords.add(keyword));
            }
            if (analysis.sheetAnalysis) {
                allSheetAnalysis.push(...analysis.sheetAnalysis);
            }
        });
        const sortedCategories = Object.entries(categoryScores)
            .sort(([, a], [, b]) => b - a);
        const topCategory = sortedCategories[0];
        const finalCategory = topCategory ? topCategory[0] : '기타';
        const finalConfidence = topCategory ? Math.min(topCategory[1], 1.0) : 0;
        const suggestedAlternatives = sortedCategories
            .slice(1, 4)
            .map(([category]) => category);
        return {
            category: finalCategory,
            confidence: finalConfidence,
            detectedKeywords: Array.from(allKeywords).slice(0, 20),
            sheetAnalysis: allSheetAnalysis,
            suggestedAlternatives
        };
    }
    convertWorkbookToExcelData(workbook, fileName) {
        const sheets = {};
        for (const sheetName of workbook.SheetNames) {
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, {
                header: 1,
                raw: false,
                defval: ''
            });
            sheets[sheetName] = {
                data: jsonData,
                range: worksheet['!ref'] || 'A1:A1'
            };
        }
        return {
            sheets,
            fileName,
            fileSize: 0,
            format: 'generic'
        };
    }
    extractAllText(excelData) {
        const allText = [];
        for (const sheet of Object.values(excelData.sheets)) {
            for (const row of sheet.data) {
                for (const cell of row) {
                    if (typeof cell === 'string' && cell.trim()) {
                        allText.push(cell.trim());
                    }
                }
            }
        }
        return allText.join(' ');
    }
    detectStudentInfoPattern(excelData) {
        const firstSheet = Object.values(excelData.sheets)[0];
        if (!firstSheet || firstSheet.data.length < 5)
            return false;
        const topRows = firstSheet.data.slice(0, 5);
        const textContent = topRows.flat().join(' ').toLowerCase();
        const studentInfoIndicators = ['성명', '학번', '학급', '학년', '생년월일'];
        const matchCount = studentInfoIndicators.filter(indicator => textContent.includes(indicator)).length;
        return matchCount >= 2;
    }
    detectDatePatterns(excelData) {
        const datePatterns = [
            /\d{4}[-.]?\d{1,2}[-.]?\d{1,2}/g,
            /\d{4}년\s*\d{1,2}월\s*\d{1,2}일/g,
            /\d{1,2}\/\d{1,2}\/\d{4}/g
        ];
        const detectedPatterns = [];
        const sampleText = this.extractAllText(excelData).slice(0, 1000);
        datePatterns.forEach((pattern, index) => {
            const matches = sampleText.match(pattern);
            if (matches && matches.length > 2) {
                detectedPatterns.push(`날짜패턴${index + 1}`);
            }
        });
        return detectedPatterns;
    }
    static getCategoryTheme(category) {
        const themes = {
            '출결상황': { color: '#f44336', icon: '📅', bgColor: '#ffebee' },
            '개인세부능력': { color: '#2196f3', icon: '📚', bgColor: '#e3f2fd' },
            '인적사항': { color: '#4caf50', icon: '👤', bgColor: '#e8f5e8' },
            '수상경력': { color: '#ff9800', icon: '🏆', bgColor: '#fff3e0' },
            '창의적체험활동': { color: '#9c27b0', icon: '🎨', bgColor: '#f3e5f5' },
            '독서활동': { color: '#795548', icon: '📖', bgColor: '#efebe9' },
            '행동특성및종합의견': { color: '#607d8b', icon: '📝', bgColor: '#eceff1' },
            '기타': { color: '#757575', icon: '📄', bgColor: '#f5f5f5' }
        };
        return themes[category] || themes['기타'];
    }
}
exports.FileCategoryDetector = FileCategoryDetector;
//# sourceMappingURL=FileCategoryDetector.js.map
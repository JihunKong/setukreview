import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export interface AttendanceRecord {
    date: string;
    type: '지각' | '조퇴' | '결과' | '결석' | '출석';
    reason?: string;
    location?: string;
    originalText: string;
}
export interface AttendanceSummary {
    totalSchoolDays: number;
    attendanceDays: number;
    absenceDays: number;
    tardyDays: number;
    earlyLeaveDays: number;
    approvedAbsenceDays: number;
}
export declare class AttendanceDuplicateValidator extends BaseValidator {
    private attendanceRecords;
    private attendanceSummaries;
    private readonly ATTENDANCE_PATTERNS;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private isAttendanceSection;
    private parseAttendanceRecord;
    private extractDate;
    private extractAttendanceType;
    private extractReason;
    private checkAttendanceDuplicates;
    private parseAttendanceSummary;
    private validateAttendanceSummary;
    private countRecordsByType;
    getAttendanceStats(studentId: string): {
        recordCount: number;
        uniqueDates: number;
        typeDistribution: Record<string, number>;
        summary?: AttendanceSummary;
    };
    clearAttendanceData(): void;
    getOverallStats(): {
        totalStudents: number;
        totalRecords: number;
        avgRecordsPerStudent: number;
        mostCommonIssues: string[];
    };
}
//# sourceMappingURL=AttendanceDuplicateValidator.d.ts.map
import { ValidationError, ValidationContext } from '../types/validation';
export declare abstract class BaseValidator {
    protected readonly type: ValidationError['type'];
    protected readonly name: string;
    constructor(type: ValidationError['type'], name: string);
    abstract validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    protected createError(message: string, rule: string, severity?: ValidationError['severity'], originalText?: string, suggestion?: string, confidence?: number): ValidationError;
    protected isKoreanText(text: string): boolean;
    protected isEnglishText(text: string): boolean;
    protected hasSpecialCharacters(text: string): boolean;
    protected countWords(text: string): number;
    protected normalizeWhitespace(text: string): string;
    protected isOnlyNumbers(text: string): boolean;
    protected isDateTime(text: string): boolean;
}
//# sourceMappingURL=BaseValidator.d.ts.map
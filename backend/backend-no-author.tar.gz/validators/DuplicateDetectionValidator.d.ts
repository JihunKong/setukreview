import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export interface SimilarityResult {
    jaccardScore: number;
    lcsScore: number;
    editDistanceScore: number;
    weightedScore: number;
    longestCommonSubstring: string;
    matchedWords: string[];
}
export interface DuplicateMatch {
    text: string;
    location: string;
    similarity: SimilarityResult;
    studentName?: string;
    section?: string;
}
export declare class DuplicateDetectionValidator extends BaseValidator {
    private textCorpus;
    private readonly SIMILARITY_THRESHOLDS;
    private readonly EDUCATION_STANDARD_EXPRESSIONS;
    private readonly WEIGHTS;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private calculateJaccardSimilarity;
    private findLongestCommonSubstring;
    private calculateEditDistanceSimilarity;
    private calculateWeightedSimilarity;
    private tokenizeKoreanText;
    private normalizeForComparison;
    private levenshteinDistance;
    private findDuplicates;
    private generateCorpusKey;
    private determineSeverity;
    private generateDuplicateMessage;
    private generateDuplicateSuggestion;
    private createEmptySimilarityResult;
    clearCorpus(): void;
    getCorpusStats(): {
        totalEntries: number;
        sections: string[];
        avgTextsPerSection: number;
    };
    private isStandardEducationExpression;
}
//# sourceMappingURL=DuplicateDetectionValidator.d.ts.map
import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export declare class InstitutionNameValidator extends BaseValidator {
    private readonly allowedInstitutions;
    private readonly prohibitedPatterns;
    private readonly allowedPatterns;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private isVolunteerActivityContext;
    private findProhibitedInstitutions;
    private findInstructorNames;
    private isAllowedInstitution;
    private suggestGenericAlternative;
}
//# sourceMappingURL=InstitutionNameValidator.d.ts.map
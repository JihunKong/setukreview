"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KoreanEnglishValidator = void 0;
const BaseValidator_1 = require("./BaseValidator");
class KoreanEnglishValidator extends BaseValidator_1.BaseValidator {
    allowedEnglishTerms;
    allowedEnglishPatterns;
    constructor() {
        super('korean_english', 'Korean/English Input Validator');
        this.allowedEnglishTerms = new Set([
            'CEO', 'PD', 'UCC', 'IT', 'POP', 'CF', 'TV', 'PAPS', 'SNS', 'PPT',
            'DVD', 'CD', 'USB', 'GPS', 'LED', 'LCD', 'AI', 'VR', 'AR',
            'URL', 'HTTP', 'HTTPS', 'WWW', 'PC', 'OS', 'SW', 'HW',
            'STEAM', 'STEM', 'IB', 'AP', 'SAT', 'TOEIC', 'TOEFL', 'IELTS',
            'GPA', 'R&E', 'MOOC',
            'OK', 'NO', 'YES', 'Q&A', 'FAQ', 'TIP', 'TOP', 'NEW', 'HOT',
            'ON', 'OFF', 'UP', 'DOWN', 'IN', 'OUT'
        ]);
        this.allowedEnglishPatterns = [
            /\b\d+[가-힣\s]*[A-Za-z]+[가-힣\s]*\d*\b/,
            /\b[A-Z][a-z]+\s[A-Z][a-z]+\b/,
            /\b(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?\b/,
            /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/,
            /\b[A-Z]{1,3}\d{2,6}[A-Z]?\b/,
            /\b\d+[a-zA-Z]{1,3}\b/
        ];
    }
    async validate(text, context) {
        const errors = [];
        if (!text || this.isOnlyNumbers(text) || this.isDateTime(text)) {
            return errors;
        }
        if (!this.isEnglishText(text)) {
            return errors;
        }
        const normalizedText = this.normalizeWhitespace(text);
        const englishMatches = this.extractEnglishContent(normalizedText);
        for (const match of englishMatches) {
            if (!this.isAllowedEnglishUsage(match, normalizedText)) {
                const error = this.createError(`허용되지 않은 영문 표현: "${match}"`, 'korean-english-rule', 'warning', text, this.suggestKoreanAlternative(match));
                errors.push(error);
            }
        }
        return errors;
    }
    extractEnglishContent(text) {
        const matches = [];
        const englishWordRegex = /\b[A-Za-z]+(?:[&][A-Za-z]+)*\b/g;
        let match;
        while ((match = englishWordRegex.exec(text)) !== null) {
            matches.push(match[0]);
        }
        const englishPhraseRegex = /\b[A-Z][a-z]+\s[A-Z][a-z]+(?:\s[A-Z][a-z]+)?\b/g;
        while ((match = englishPhraseRegex.exec(text)) !== null) {
            matches.push(match[0]);
        }
        return [...new Set(matches)];
    }
    isAllowedEnglishUsage(englishContent, fullText) {
        const upperContent = englishContent.toUpperCase();
        if (this.allowedEnglishTerms.has(upperContent)) {
            return true;
        }
        for (const pattern of this.allowedEnglishPatterns) {
            if (pattern.test(englishContent) || pattern.test(fullText)) {
                return true;
            }
        }
        if (this.isForeignName(englishContent)) {
            return true;
        }
        if (this.isBookTitleOrPublication(englishContent, fullText)) {
            return true;
        }
        if (this.isTechnicalTerm(englishContent, fullText)) {
            return true;
        }
        return false;
    }
    isForeignName(text) {
        const namePattern = /^[A-Z][a-z]+(?:\s[A-Z][a-z]+){1,2}$/;
        return namePattern.test(text);
    }
    isBookTitleOrPublication(englishContent, fullText) {
        const bookContexts = ['도서', '책', '저서', '논문', '학술지', '잡지', '신문'];
        const hasBookContext = bookContexts.some(context => fullText.includes(context));
        const quotedPattern = new RegExp(`['"]${englishContent.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}['"]`);
        const isQuoted = quotedPattern.test(fullText);
        return hasBookContext || isQuoted;
    }
    isTechnicalTerm(englishContent, fullText) {
        const technicalContexts = [
            '프로그램', '시스템', '소프트웨어', '하드웨어', '네트워크',
            '데이터베이스', '알고리즘', '인터페이스', '플랫폼', '애플리케이션'
        ];
        return technicalContexts.some(context => fullText.includes(context));
    }
    suggestKoreanAlternative(englishContent) {
        const alternatives = {
            'PROGRAM': '프로그램',
            'SYSTEM': '시스템',
            'PROJECT': '프로젝트',
            'TEAM': '팀',
            'GROUP': '그룹',
            'CLASS': '수업',
            'COURSE': '과정',
            'TEST': '시험',
            'EXAM': '시험',
            'STUDY': '학습',
            'CLUB': '동아리',
            'ACTIVITY': '활동',
            'EVENT': '행사',
            'CONTEST': '대회',
            'COMPETITION': '경시대회',
            'FESTIVAL': '축제',
            'CAMP': '캠프',
            'WORKSHOP': '워크숍',
            'SEMINAR': '세미나',
            'CONFERENCE': '회의'
        };
        const upperContent = englishContent.toUpperCase();
        return alternatives[upperContent] || `한글 표기 권장`;
    }
}
exports.KoreanEnglishValidator = KoreanEnglishValidator;
//# sourceMappingURL=KoreanEnglishValidator.js.map
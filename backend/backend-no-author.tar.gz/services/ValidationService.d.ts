import { ValidationResult, ExcelData } from '../types/validation';
export declare class ValidationService {
    private static validationResults;
    private static activeValidations;
    static validateData(validationId: string, excelData: ExcelData): Promise<void>;
    private static validateNEISData;
    private static validateGenericData;
    static storeResult(validationId: string, result: ValidationResult): void;
    static getResult(validationId: string): ValidationResult | undefined;
    static cancelValidation(validationId: string): void;
    static getRecentValidations(limit?: number): ValidationResult[];
    static cleanup(): void;
    private static getCellReference;
    private static getColumnLetter;
    private static getAdjacentCells;
    private static getAdjacentCellsFromArray;
    private static getDisplayName;
}
//# sourceMappingURL=ValidationService.d.ts.map
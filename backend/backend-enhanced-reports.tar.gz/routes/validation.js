"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validationRouter = void 0;
const express_1 = __importDefault(require("express"));
const express_validator_1 = require("express-validator");
const ValidationService_1 = require("../services/ValidationService");
const SelectiveValidationService_1 = require("../services/SelectiveValidationService");
const router = express_1.default.Router();
exports.validationRouter = router;
router.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (origin.includes('.up.railway.app') || origin.includes('localhost') || process.env.NODE_ENV !== 'production')) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
        res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    }
    next();
});
router.options('*', (req, res) => {
    res.status(200).end();
});
router.get('/:id', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid validation ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const validationId = req.params.id;
    const result = ValidationService_1.ValidationService.getResult(validationId);
    if (!result) {
        return res.status(404).json({
            error: 'Validation not found',
            message: `No validation found with ID: ${validationId}`
        });
    }
    res.json(result);
});
router.delete('/:id', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid validation ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const validationId = req.params.id;
    const result = ValidationService_1.ValidationService.getResult(validationId);
    if (!result) {
        return res.status(404).json({
            error: 'Validation not found'
        });
    }
    if (result.status === 'completed' || result.status === 'failed') {
        return res.status(400).json({
            error: 'Cannot cancel completed validation'
        });
    }
    ValidationService_1.ValidationService.cancelValidation(validationId);
    res.json({
        success: true,
        message: 'Validation cancelled'
    });
});
router.get('/:id/stats', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid validation ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const validationId = req.params.id;
    const result = ValidationService_1.ValidationService.getResult(validationId);
    if (!result) {
        return res.status(404).json({
            error: 'Validation not found'
        });
    }
    const stats = {
        overview: result.summary,
        errorsByType: {},
        errorsBySeverity: {
            error: result.errors.length,
            warning: result.warnings.length,
            info: result.info.length,
        },
        processingTime: result.completedAt && result.createdAt
            ? result.completedAt.getTime() - result.createdAt.getTime()
            : null,
        fileName: result.fileName,
        status: result.status,
        progress: result.progress,
    };
    [...result.errors, ...result.warnings, ...result.info].forEach(error => {
        stats.errorsByType[error.type] = (stats.errorsByType[error.type] || 0) + 1;
    });
    res.json(stats);
});
router.get('/', (req, res) => {
    const recentValidations = ValidationService_1.ValidationService.getRecentValidations(10);
    res.json({
        validations: recentValidations.map(result => ({
            id: result.id,
            fileName: result.fileName,
            status: result.status,
            progress: result.progress,
            errorCount: result.summary.errorCount,
            createdAt: result.createdAt,
            completedAt: result.completedAt,
        }))
    });
});
const selectiveValidationService = SelectiveValidationService_1.SelectiveValidationService.getInstance();
router.post('/batch/:sessionId', [
    (0, express_validator_1.param)('sessionId').isUUID().withMessage('Invalid session ID'),
    (0, express_validator_1.body)('options').isObject().withMessage('Validation options required'),
    (0, express_validator_1.body)('options.validateAll').optional().isBoolean(),
    (0, express_validator_1.body)('options.selectedCategories').optional().isArray(),
    (0, express_validator_1.body)('options.selectedFileIds').optional().isArray(),
    (0, express_validator_1.body)('options.skipDuplicateDetection').optional().isBoolean(),
    (0, express_validator_1.body)('options.enableCrossValidation').optional().isBoolean(),
    (0, express_validator_1.body)('options.priority').optional().isIn(['speed', 'accuracy', 'balanced']),
    (0, express_validator_1.body)('options.maxConcurrency').optional().isInt({ min: 1, max: 10 })
], async (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    try {
        const { sessionId } = req.params;
        const { options } = req.body;
        const batchId = await selectiveValidationService.startBatchValidation(sessionId, options);
        res.json({
            success: true,
            batchId,
            sessionId,
            message: 'Batch validation started'
        });
    }
    catch (error) {
        console.error('Batch validation start error:', error);
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to start batch validation'
        });
    }
});
router.post('/batch/:sessionId/category/:category', [
    (0, express_validator_1.param)('sessionId').isUUID().withMessage('Invalid session ID'),
    (0, express_validator_1.param)('category').isString().withMessage('Category is required'),
    (0, express_validator_1.body)('options').optional().isObject()
], async (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    try {
        const { sessionId, category } = req.params;
        const options = req.body.options || {};
        const batchId = await selectiveValidationService.validateCategory(sessionId, category, options);
        res.json({
            success: true,
            batchId,
            sessionId,
            category,
            message: `Validation started for category: ${category}`
        });
    }
    catch (error) {
        console.error('Category validation start error:', error);
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to start category validation'
        });
    }
});
router.post('/batch/:sessionId/all', [
    (0, express_validator_1.param)('sessionId').isUUID().withMessage('Invalid session ID'),
    (0, express_validator_1.body)('options').optional().isObject()
], async (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    try {
        const { sessionId } = req.params;
        const options = req.body.options || {};
        const batchId = await selectiveValidationService.validateAll(sessionId, options);
        res.json({
            success: true,
            batchId,
            sessionId,
            message: 'Validation started for all files'
        });
    }
    catch (error) {
        console.error('Validate all start error:', error);
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to start validation for all files'
        });
    }
});
router.get('/batch/:batchId', [
    (0, express_validator_1.param)('batchId').isUUID().withMessage('Invalid batch ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const { batchId } = req.params;
    const batchResult = selectiveValidationService.getBatchResult(batchId);
    if (!batchResult) {
        return res.status(404).json({
            error: 'Batch validation not found',
            message: `No batch validation found with ID: ${batchId}`
        });
    }
    const results = {};
    let conversionErrors = 0;
    batchResult.results.forEach((value, key) => {
        try {
            if (value && typeof value === 'object') {
                results[key] = value;
            }
            else {
                console.warn(`⚠️ Invalid validation result for key ${key}:`, value);
                conversionErrors++;
            }
        }
        catch (error) {
            console.error(`❌ Error converting result for key ${key}:`, error);
            conversionErrors++;
        }
    });
    console.log(`📊 Batch ${batchId} serialization:`, {
        totalResults: batchResult.results.size,
        serializedResults: Object.keys(results).length,
        conversionErrors,
        resultKeys: Array.from(batchResult.results.keys()),
        serializedKeys: Object.keys(results)
    });
    res.json({
        ...batchResult,
        results
    });
});
router.delete('/batch/:batchId', [
    (0, express_validator_1.param)('batchId').isUUID().withMessage('Invalid batch ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const { batchId } = req.params;
    const success = selectiveValidationService.cancelBatchValidation(batchId);
    if (!success) {
        return res.status(404).json({
            error: 'Cannot cancel batch validation',
            message: 'Batch not found or already completed'
        });
    }
    res.json({
        success: true,
        message: 'Batch validation cancelled'
    });
});
router.get('/batch/:batchId/stats/category', [
    (0, express_validator_1.param)('batchId').isUUID().withMessage('Invalid batch ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const { batchId } = req.params;
    const stats = selectiveValidationService.getCategoryValidationStats(batchId);
    res.json({
        batchId,
        categoryStats: stats
    });
});
router.get('/batch/session/:sessionId', [
    (0, express_validator_1.param)('sessionId').isUUID().withMessage('Invalid session ID')
], (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    const { sessionId } = req.params;
    const batches = selectiveValidationService.getSessionBatches(sessionId);
    const serializedBatches = batches.map(batch => ({
        ...batch,
        results: Object.fromEntries(batch.results)
    }));
    res.json({
        sessionId,
        batches: serializedBatches
    });
});
router.get('/batch/stats/service', (req, res) => {
    const stats = selectiveValidationService.getServiceStats();
    res.json({
        success: true,
        stats
    });
});
router.post('/session/:sessionId', [
    (0, express_validator_1.param)('sessionId').isUUID().withMessage('Invalid session ID')
], async (req, res) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Invalid request',
            details: errors.array()
        });
    }
    try {
        const { sessionId } = req.params;
        const results = await selectiveValidationService.validateAllFilesSync(sessionId);
        res.json({
            success: true,
            sessionId,
            results,
            message: 'All files validated successfully'
        });
    }
    catch (error) {
        console.error('Session validation error:', error);
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'Failed to validate session files'
        });
    }
});
//# sourceMappingURL=validation.js.map
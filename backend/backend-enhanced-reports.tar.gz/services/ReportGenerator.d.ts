import { ValidationResult } from '../types/validation';
export declare class ReportGenerator {
    generateExcelReport(result: ValidationResult): Promise<Buffer>;
    generateCSVReport(result: ValidationResult): Promise<string>;
    private getTypeDisplayName;
    private getSeverityDisplayName;
    private escapeCsvField;
    generateBatchExcelReport(results: ValidationResult[]): Promise<Buffer>;
    generateBatchCSVReport(results: ValidationResult[]): Promise<string>;
    generateZipReport(results: ValidationResult[]): Promise<Buffer>;
}
//# sourceMappingURL=ReportGenerator.d.ts.map
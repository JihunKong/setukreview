"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.NEISExcelProcessor = void 0;
const XLSX = __importStar(require("xlsx"));
class NEISExcelProcessor {
    NEIS_STRUCTURE = {
        STUDENT_INFO: {
            NAME_ROW: 3,
            NAME_COL: 2,
            STUDENT_NUMBER_ROW: 3,
            STUDENT_NUMBER_COL: 5,
            CLASS_ROW: 3,
            CLASS_COL: 8,
            GRADE_ROW: 3,
            GRADE_COL: 10,
            SCHOOL_ROW: 1,
            SCHOOL_COL: 2,
        },
        SECTION_MARKERS: {
            '학적사항': { startKeywords: ['학적사항', '학적 사항'], headerRow: 5, dataStartOffset: 2 },
            '출결상황': { startKeywords: ['출결상황', '출결 상황'], headerRow: null, dataStartOffset: 2 },
            '수상경력': { startKeywords: ['수상경력', '수상 경력'], headerRow: null, dataStartOffset: 2 },
            '자격증및인증취득상황': { startKeywords: ['자격증', '인증취득'], headerRow: null, dataStartOffset: 2 },
            '창의적체험활동상황': { startKeywords: ['창의적체험활동', '창의적 체험활동'], headerRow: null, dataStartOffset: 2 },
            '교과학습발달상황': { startKeywords: ['교과학습', '학습발달', '교과 학습'], headerRow: null, dataStartOffset: 2 },
            '독서활동상황': { startKeywords: ['독서활동', '독서 활동'], headerRow: null, dataStartOffset: 2 },
            '행동특성및종합의견': { startKeywords: ['행동특성', '종합의견'], headerRow: null, dataStartOffset: 2 },
        },
        SKIP_PATTERNS: [
            '※',
            '주)',
            '구분',
            '항목',
            '비고',
            '계',
            '합계',
            '총',
            '전체',
            '학년도',
            '학기',
            '기준일',
        ],
        VALIDATION_CONTEXTS: {
            STUDENT_NAME: '학생명',
            INSTRUCTOR_NAME: '교사명',
            SCHOOL_NAME: '학교명',
            PERIOD: '기간',
            SUBJECT: '과목',
            ACTIVITY: '활동',
            AWARD: '상',
            CERTIFICATE: '자격증',
        }
    };
    async processNEISFile(buffer, fileName) {
        try {
            console.log(`📚 Processing NEIS file: ${fileName}`);
            const workbook = XLSX.read(buffer, {
                type: 'buffer',
                cellDates: true,
                cellNF: false,
                cellText: false
            });
            const students = [];
            for (const sheetName of workbook.SheetNames) {
                const worksheet = workbook.Sheets[sheetName];
                if (!worksheet)
                    continue;
                console.log(`📝 Processing sheet: ${sheetName}`);
                const data = this.worksheetToArray(worksheet);
                const studentRecords = this.extractStudentRecords(data, sheetName);
                students.push(...studentRecords);
            }
            console.log(`👥 Found ${students.length} student records in NEIS file`);
            return students;
        }
        catch (error) {
            console.error('NEIS processing error:', error);
            throw new Error(`Failed to process NEIS file: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    worksheetToArray(worksheet) {
        const range = worksheet['!ref'];
        if (!range)
            return [];
        const decodedRange = XLSX.utils.decode_range(range);
        const data = [];
        for (let R = decodedRange.s.r; R <= decodedRange.e.r; ++R) {
            const row = [];
            for (let C = decodedRange.s.c; C <= decodedRange.e.c; ++C) {
                const cellAddress = XLSX.utils.encode_cell({ c: C, r: R });
                const cell = worksheet[cellAddress];
                let cellValue = '';
                if (cell) {
                    if (cell.t === 'n') {
                        cellValue = String(cell.v);
                    }
                    else if (cell.t === 's') {
                        cellValue = String(cell.v).trim();
                    }
                    else if (cell.t === 'b') {
                        cellValue = cell.v ? 'TRUE' : 'FALSE';
                    }
                    else if (cell.t === 'd') {
                        cellValue = cell.v instanceof Date ? cell.v.toISOString().split('T')[0] : String(cell.v);
                    }
                    else {
                        cellValue = String(cell.v || '').trim();
                    }
                }
                row[C] = cellValue;
            }
            data[R] = row;
        }
        return data;
    }
    extractStudentRecords(data, sheetName) {
        const records = [];
        const studentInfo = this.extractStudentInfo(data);
        const sections = this.extractSections(data);
        const record = {
            studentInfo,
            sections,
            metadata: {
                recordType: 'NEIS',
                processingDate: new Date(),
                totalSections: Object.keys(sections).length,
                totalDataCells: this.countDataCells(sections),
            }
        };
        records.push(record);
        return records;
    }
    extractStudentInfo(data) {
        const dynamicInfo = this.extractStudentInfoDynamically(data);
        const fixedInfo = this.extractStudentInfoFromFixedPositions(data);
        const alternativeName = this.findStudentNameAlternatively(data);
        return {
            name: dynamicInfo.name || fixedInfo.name || alternativeName || '미상',
            studentNumber: dynamicInfo.studentNumber || fixedInfo.studentNumber || '',
            class: dynamicInfo.class || fixedInfo.class || '',
            grade: dynamicInfo.grade || fixedInfo.grade || '',
            school: dynamicInfo.school || fixedInfo.school || '',
        };
    }
    extractStudentInfoFromFixedPositions(data) {
        const info = this.NEIS_STRUCTURE.STUDENT_INFO;
        return {
            name: this.getCellValue(data, info.NAME_ROW, info.NAME_COL),
            studentNumber: this.getCellValue(data, info.STUDENT_NUMBER_ROW, info.STUDENT_NUMBER_COL),
            class: this.getCellValue(data, info.CLASS_ROW, info.CLASS_COL),
            grade: this.getCellValue(data, info.GRADE_ROW, info.GRADE_COL),
            school: this.getCellValue(data, info.SCHOOL_ROW, info.SCHOOL_COL),
        };
    }
    extractStudentInfoDynamically(data) {
        const result = {};
        for (let row = 0; row < Math.min(data.length, 10); row++) {
            if (!data[row])
                continue;
            for (let col = 0; col < data[row].length; col++) {
                const cellValue = data[row][col];
                if (!cellValue || typeof cellValue !== 'string')
                    continue;
                const cellText = cellValue.trim().toLowerCase();
                if (this.isNameIndicator(cellText)) {
                    const name = this.findAdjacentValue(data, row, col);
                    if (name && this.isValidName(name)) {
                        result.name = name;
                    }
                }
                if (this.isStudentNumberIndicator(cellText)) {
                    const studentNumber = this.findAdjacentValue(data, row, col);
                    if (studentNumber && this.isValidStudentNumber(studentNumber)) {
                        result.studentNumber = studentNumber;
                    }
                }
                if (this.isClassIndicator(cellText)) {
                    const classInfo = this.findAdjacentValue(data, row, col);
                    if (classInfo) {
                        result.class = classInfo;
                    }
                }
                if (this.isSchoolIndicator(cellText)) {
                    const school = this.findAdjacentValue(data, row, col);
                    if (school && school.length > 2) {
                        result.school = school;
                    }
                }
            }
        }
        return result;
    }
    extractSections(data) {
        const sections = {};
        for (const [sectionName, config] of Object.entries(this.NEIS_STRUCTURE.SECTION_MARKERS)) {
            const sectionData = this.extractSection(data, sectionName, config);
            if (sectionData) {
                sections[sectionName] = sectionData;
            }
        }
        return sections;
    }
    extractSection(data, sectionName, config) {
        const startRow = this.findSectionStart(data, config.startKeywords);
        if (startRow === -1) {
            console.warn(`Section '${sectionName}' not found in data`);
            return null;
        }
        const endRow = this.findSectionEnd(data, startRow);
        const headerRow = startRow + 1;
        const headers = data[headerRow] ? data[headerRow].filter(cell => cell && cell.trim()) : [];
        const contentStartRow = startRow + config.dataStartOffset;
        const contentRows = [];
        for (let i = contentStartRow; i <= endRow; i++) {
            if (!data[i])
                continue;
            const row = data[i];
            if (this.isContentRow(row)) {
                contentRows.push(row);
            }
        }
        return {
            title: sectionName,
            startRow,
            endRow,
            data: data.slice(startRow, endRow + 1),
            headers,
            contentRows,
        };
    }
    findSectionStart(data, keywords) {
        for (let i = 0; i < data.length; i++) {
            if (!data[i])
                continue;
            for (const row of [data[i]]) {
                for (const cell of row) {
                    if (cell && typeof cell === 'string') {
                        for (const keyword of keywords) {
                            if (cell.includes(keyword)) {
                                return i;
                            }
                        }
                    }
                }
            }
        }
        return -1;
    }
    findSectionEnd(data, startRow) {
        for (let i = startRow + 1; i < data.length; i++) {
            if (!data[i])
                continue;
            const row = data[i];
            for (const cell of row) {
                if (cell && typeof cell === 'string') {
                    for (const [sectionName, config] of Object.entries(this.NEIS_STRUCTURE.SECTION_MARKERS)) {
                        for (const keyword of config.startKeywords) {
                            if (cell.includes(keyword)) {
                                return i - 1;
                            }
                        }
                    }
                }
            }
        }
        return Math.min(startRow + 50, data.length - 1);
    }
    isContentRow(row) {
        if (!row || row.length === 0)
            return false;
        const nonEmptyCount = row.filter(cell => cell && cell.trim()).length;
        if (nonEmptyCount === 0)
            return false;
        const rowText = row.join(' ').toLowerCase();
        for (const pattern of this.NEIS_STRUCTURE.SKIP_PATTERNS) {
            if (rowText.includes(pattern.toLowerCase())) {
                return false;
            }
        }
        return true;
    }
    getCellValue(data, row, col) {
        if (!data[row] || !data[row][col])
            return '';
        return data[row][col].toString().trim();
    }
    countDataCells(sections) {
        let count = 0;
        for (const section of Object.values(sections)) {
            if (section) {
                count += section.contentRows.flat().filter(cell => cell && cell.trim()).length;
            }
        }
        return count;
    }
    static isNEISFormat(data) {
        if (!data || data.length < 5)
            return false;
        const searchText = data.slice(0, 10)
            .flat()
            .join(' ')
            .toLowerCase();
        const neisKeywords = [
            '학적사항', '출결상황', '수상경력', '창의적체험활동',
            '교과학습', '독서활동', '행동특성', '종합의견',
            '나이스', 'neis', '학교', '학생'
        ];
        let keywordCount = 0;
        for (const keyword of neisKeywords) {
            if (searchText.includes(keyword)) {
                keywordCount++;
            }
        }
        return keywordCount >= 3;
    }
    isNameIndicator(text) {
        const nameIndicators = ['성명', '학생명', '이름', '학생이름', 'name'];
        return nameIndicators.some(indicator => text.includes(indicator));
    }
    isStudentNumberIndicator(text) {
        const numberIndicators = ['학번', '학적번호', '번호', 'id', 'number'];
        return numberIndicators.some(indicator => text.includes(indicator));
    }
    isClassIndicator(text) {
        const classIndicators = ['학급', '반', 'class'];
        return classIndicators.some(indicator => text.includes(indicator));
    }
    isSchoolIndicator(text) {
        const schoolIndicators = ['학교', '교명', 'school'];
        return schoolIndicators.some(indicator => text.includes(indicator));
    }
    findAdjacentValue(data, row, col) {
        const directions = [
            [0, 1],
            [1, 0],
            [0, -1],
            [-1, 0],
        ];
        for (const [dr, dc] of directions) {
            const newRow = row + dr;
            const newCol = col + dc;
            if (newRow >= 0 && newRow < data.length && newCol >= 0) {
                const value = this.getCellValue(data, newRow, newCol);
                if (value && value.trim() && !this.isIndicatorText(value)) {
                    return value.trim();
                }
            }
        }
        return null;
    }
    isIndicatorText(text) {
        const indicators = ['성명', '학생명', '이름', '학번', '학급', '반', '학교', '교명'];
        const lowerText = text.toLowerCase();
        return indicators.some(indicator => lowerText.includes(indicator));
    }
    isValidName(name) {
        if (!name || !name.trim())
            return false;
        const trimmed = name.trim();
        const koreanNamePattern = /^[가-힣]{2,5}$/;
        if (koreanNamePattern.test(trimmed))
            return true;
        const mixedNamePattern = /^[가-힣a-zA-Z\(\)\s]{2,10}$/;
        if (mixedNamePattern.test(trimmed) && /[가-힣]/.test(trimmed))
            return true;
        const nonNameKeywords = ['학생', '성명', '이름', '번호', '학급', '반', '학교', '년', '월', '일'];
        if (nonNameKeywords.some(keyword => trimmed.includes(keyword)))
            return false;
        return false;
    }
    isValidStudentNumber(number) {
        return /\d+/.test(number) && number.length >= 2;
    }
    findStudentNameAlternatively(data) {
        for (let row = 0; row < Math.min(data.length, 15); row++) {
            if (!data[row])
                continue;
            for (let col = 0; col < Math.min(data[row].length, 10); col++) {
                const cellValue = data[row][col];
                if (!cellValue)
                    continue;
                const trimmed = cellValue.trim();
                if (this.looksLikeStandaloneName(trimmed)) {
                    return trimmed;
                }
                const nameMatch = trimmed.match(/(?:이름|학생명|성명|name)\s*[:：]\s*([가-힣]{2,5})/i);
                if (nameMatch && nameMatch[1]) {
                    return nameMatch[1];
                }
                const parenthesesMatch = trimmed.match(/\(([가-힣]{2,4})\)/);
                if (parenthesesMatch && parenthesesMatch[1] && this.isValidName(parenthesesMatch[1])) {
                    return parenthesesMatch[1];
                }
            }
        }
        return null;
    }
    looksLikeStandaloneName(text) {
        if (!text || text.length < 2 || text.length > 5)
            return false;
        if (!/^[가-힣]+$/.test(text))
            return false;
        const commonNonNames = [
            '학교', '학생', '학급', '학년', '학기', '선생', '담임', '교사', '과목',
            '국어', '영어', '수학', '과학', '사회', '음악', '미술', '체육',
            '월요', '화요', '수요', '목요', '금요', '토요', '일요',
            '오전', '오후', '시간', '분간', '년도', '학기', '반년',
            '출석', '결석', '지각', '조퇴', '수업', '시험', '평가'
        ];
        if (commonNonNames.includes(text))
            return false;
        const charCount = text.split('').reduce((acc, char) => {
            acc[char] = (acc[char] || 0) + 1;
            return acc;
        }, {});
        const maxCount = Math.max(...Object.values(charCount));
        if (maxCount > Math.ceil(text.length / 2))
            return false;
        return true;
    }
}
exports.NEISExcelProcessor = NEISExcelProcessor;
//# sourceMappingURL=NEISExcelProcessor.js.map
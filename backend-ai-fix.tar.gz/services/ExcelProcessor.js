"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExcelProcessor = void 0;
const XLSX = __importStar(require("xlsx"));
const NEISExcelProcessor_1 = require("./NEISExcelProcessor");
class ExcelProcessor {
    async processFile(buffer, fileName) {
        try {
            console.log(`📁 Processing file: ${fileName}`);
            const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: true, cellNF: false, cellText: false });
            const genericData = this.convertToGenericFormat(workbook, buffer.length, fileName);
            const isNEIS = this.detectNEISFormat(genericData);
            console.log(`🔍 Detected format: ${isNEIS ? 'NEIS' : 'Generic'}`);
            if (isNEIS) {
                const neisProcessor = new NEISExcelProcessor_1.NEISExcelProcessor();
                const neisRecords = await neisProcessor.processNEISFile(buffer, fileName);
                return {
                    ...genericData,
                    format: 'neis',
                    neisData: {
                        students: neisRecords,
                        metadata: {
                            processingDate: new Date(),
                            totalStudents: neisRecords.length,
                            totalSections: neisRecords.reduce((total, record) => total + Object.keys(record.sections).length, 0),
                            detectedFormat: 'NEIS',
                        }
                    }
                };
            }
            else {
                return {
                    ...genericData,
                    format: 'generic'
                };
            }
        }
        catch (error) {
            console.error('Excel processing error:', error);
            throw new Error(`Failed to process Excel file: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    convertToGenericFormat(workbook, fileSize, fileName) {
        const excelData = {
            sheets: {},
            fileName,
            fileSize
        };
        workbook.SheetNames.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            if (!worksheet)
                return;
            const range = worksheet['!ref'];
            if (!range)
                return;
            const data = [];
            const decodedRange = XLSX.utils.decode_range(range);
            for (let R = decodedRange.s.r; R <= decodedRange.e.r; ++R) {
                const row = [];
                for (let C = decodedRange.s.c; C <= decodedRange.e.c; ++C) {
                    const cellAddress = XLSX.utils.encode_cell({ c: C, r: R });
                    const cell = worksheet[cellAddress];
                    if (cell) {
                        let cellValue = '';
                        if (cell.t === 'n') {
                            cellValue = String(cell.v);
                        }
                        else if (cell.t === 's') {
                            cellValue = String(cell.v);
                        }
                        else if (cell.t === 'b') {
                            cellValue = cell.v ? 'TRUE' : 'FALSE';
                        }
                        else if (cell.t === 'd') {
                            cellValue = cell.v instanceof Date ? cell.v.toISOString().split('T')[0] : String(cell.v);
                        }
                        else {
                            cellValue = String(cell.v || '');
                        }
                        row[C] = cellValue;
                    }
                    else {
                        row[C] = '';
                    }
                }
                data[R] = row;
            }
            excelData.sheets[sheetName] = {
                data,
                range
            };
        });
        return excelData;
    }
    detectNEISFormat(excelData) {
        for (const [sheetName, sheet] of Object.entries(excelData.sheets)) {
            if (NEISExcelProcessor_1.NEISExcelProcessor.isNEISFormat(sheet.data)) {
                return true;
            }
        }
        return false;
    }
    getCellReference(row, col) {
        return XLSX.utils.encode_cell({ r: row, c: col });
    }
    getColumnLetter(col) {
        let letter = '';
        while (col >= 0) {
            letter = String.fromCharCode(col % 26 + 65) + letter;
            col = Math.floor(col / 26) - 1;
        }
        return letter;
    }
    validateFileFormat(buffer) {
        try {
            XLSX.read(buffer, { type: 'buffer' });
            return true;
        }
        catch {
            return false;
        }
    }
    getFileInfo(buffer, fileName) {
        try {
            if (!this.validateFileFormat(buffer)) {
                return { isValid: false, error: 'Invalid Excel file format' };
            }
            const workbook = XLSX.read(buffer, { type: 'buffer' });
            return {
                isValid: true,
                info: {
                    fileName,
                    fileSize: buffer.length,
                    sheetCount: workbook.SheetNames.length,
                    sheets: workbook.SheetNames,
                    createdDate: new Date().toISOString()
                }
            };
        }
        catch (error) {
            return {
                isValid: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
}
exports.ExcelProcessor = ExcelProcessor;
//# sourceMappingURL=ExcelProcessor.js.map
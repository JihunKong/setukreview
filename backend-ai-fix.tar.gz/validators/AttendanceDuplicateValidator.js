"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttendanceDuplicateValidator = void 0;
const BaseValidator_1 = require("./BaseValidator");
class AttendanceDuplicateValidator extends BaseValidator_1.BaseValidator {
    attendanceRecords = new Map();
    attendanceSummaries = new Map();
    ATTENDANCE_PATTERNS = {
        DATE_PATTERNS: [
            /(\d{4})[-./년](\d{1,2})[-./월](\d{1,2})일?/,
            /(\d{1,2})[-./월](\d{1,2})일?/,
            /(\d{1,2})\/(\d{1,2})/
        ],
        ATTENDANCE_TYPES: {
            '결석': ['결석', '무단결석', '병결', '사고결석', '기타결석'],
            '지각': ['지각', '무단지각', '병지각', '사고지각', '기타지각'],
            '조퇴': ['조퇴', '무단조퇴', '병조퇴', '사고조퇴', '기타조퇴'],
            '결과': ['결과', '무단결과', '병결과', '사고결과', '기타결과'],
            '출석': ['출석', '정상출석']
        },
        SUMMARY_KEYWORDS: [
            '수업일수', '출석일수', '결석일수', '지각일수', '조퇴일수', '결과일수',
            '총', '계', '합계', '누계'
        ]
    };
    constructor() {
        super('attendance_duplicate', 'Attendance Duplicate Validator');
    }
    async validate(text, context) {
        const errors = [];
        if (!text || text.length < 3) {
            return errors;
        }
        if (!this.isAttendanceSection(context)) {
            return errors;
        }
        const studentId = context.studentName || 'unknown';
        if (!this.attendanceRecords.has(studentId)) {
            this.attendanceRecords.set(studentId, []);
        }
        const attendanceRecord = this.parseAttendanceRecord(text, context);
        if (attendanceRecord) {
            const duplicateErrors = this.checkAttendanceDuplicates(studentId, attendanceRecord, context);
            errors.push(...duplicateErrors);
            this.attendanceRecords.get(studentId).push(attendanceRecord);
        }
        const summaryData = this.parseAttendanceSummary(text);
        if (summaryData) {
            this.attendanceSummaries.set(studentId, summaryData);
            const summaryErrors = this.validateAttendanceSummary(studentId, summaryData, context);
            errors.push(...summaryErrors);
        }
        return errors;
    }
    isAttendanceSection(context) {
        const sectionIndicators = ['출결상황', '출결', '결석', '지각', '조퇴', '출석'];
        const contextText = `${context.section} ${context.sheet}`.toLowerCase();
        return sectionIndicators.some(indicator => contextText.includes(indicator));
    }
    parseAttendanceRecord(text, context) {
        const dateMatch = this.extractDate(text);
        const typeMatch = this.extractAttendanceType(text);
        if (!dateMatch && !typeMatch) {
            return null;
        }
        return {
            date: dateMatch || '',
            type: typeMatch || '출석',
            reason: this.extractReason(text),
            location: `${context.sheet}!${context.cell}`,
            originalText: text
        };
    }
    extractDate(text) {
        for (const pattern of this.ATTENDANCE_PATTERNS.DATE_PATTERNS) {
            const match = text.match(pattern);
            if (match) {
                if (match[1] && match[2] && match[3]) {
                    const year = match[1].length === 4 ? match[1] : `20${match[1]}`;
                    const month = match[2].padStart(2, '0');
                    const day = match[3].padStart(2, '0');
                    return `${year}-${month}-${day}`;
                }
                else if (match[1] && match[2]) {
                    const year = new Date().getFullYear();
                    const month = match[1].padStart(2, '0');
                    const day = match[2].padStart(2, '0');
                    return `${year}-${month}-${day}`;
                }
            }
        }
        return null;
    }
    extractAttendanceType(text) {
        for (const [mainType, variants] of Object.entries(this.ATTENDANCE_PATTERNS.ATTENDANCE_TYPES)) {
            for (const variant of variants) {
                if (text.includes(variant)) {
                    return mainType;
                }
            }
        }
        return null;
    }
    extractReason(text) {
        let reason = text;
        for (const pattern of this.ATTENDANCE_PATTERNS.DATE_PATTERNS) {
            reason = reason.replace(pattern, '').trim();
        }
        for (const variants of Object.values(this.ATTENDANCE_PATTERNS.ATTENDANCE_TYPES)) {
            for (const variant of variants) {
                reason = reason.replace(new RegExp(variant, 'g'), '').trim();
            }
        }
        return reason.replace(/\s+/g, ' ').trim();
    }
    checkAttendanceDuplicates(studentId, newRecord, context) {
        const errors = [];
        const existingRecords = this.attendanceRecords.get(studentId) || [];
        for (const existing of existingRecords) {
            if (newRecord.date && existing.date === newRecord.date) {
                if (existing.type === newRecord.type) {
                    const error = this.createError(`동일 날짜(${newRecord.date})에 같은 유형(${newRecord.type})의 출결 기록이 중복됨`, 'duplicate-attendance-date', 'error', newRecord.originalText, '중복된 출결 기록을 확인하고 하나만 남기세요');
                    errors.push(error);
                }
                else {
                    const error = this.createError(`동일 날짜(${newRecord.date})에 여러 출결 기록이 있음: ${existing.type}, ${newRecord.type}`, 'multiple-attendance-same-date', 'warning', newRecord.originalText, '같은 날짜의 여러 출결 기록이 올바른지 확인하세요');
                    errors.push(error);
                }
            }
            if (existing.originalText.trim() === newRecord.originalText.trim()) {
                const error = this.createError('동일한 출결 기록이 중복 입력됨', 'duplicate-attendance-content', 'error', newRecord.originalText, '중복된 내용을 삭제하세요');
                errors.push(error);
            }
        }
        return errors;
    }
    parseAttendanceSummary(text) {
        if (!this.ATTENDANCE_PATTERNS.SUMMARY_KEYWORDS.some(keyword => text.includes(keyword))) {
            return null;
        }
        const numbers = text.match(/\d+/g);
        if (!numbers || numbers.length < 2) {
            return null;
        }
        const extractedNumbers = numbers.map(n => parseInt(n, 10));
        return {
            totalSchoolDays: extractedNumbers[0] || 0,
            attendanceDays: extractedNumbers[1] || 0,
            absenceDays: extractedNumbers[2] || 0,
            tardyDays: extractedNumbers[3] || 0,
            earlyLeaveDays: extractedNumbers[4] || 0,
            approvedAbsenceDays: extractedNumbers[5] || 0
        };
    }
    validateAttendanceSummary(studentId, summary, context) {
        const errors = [];
        const totalAccounted = summary.attendanceDays + summary.absenceDays;
        if (summary.totalSchoolDays > 0 && totalAccounted > 0) {
            if (Math.abs(totalAccounted - summary.totalSchoolDays) > 1) {
                const error = this.createError(`출석일수(${summary.attendanceDays}) + 결석일수(${summary.absenceDays}) = ${totalAccounted}일이 수업일수(${summary.totalSchoolDays})와 일치하지 않음`, 'attendance-summary-mismatch', 'error', `수업일수: ${summary.totalSchoolDays}, 출석일수: ${summary.attendanceDays}, 결석일수: ${summary.absenceDays}`, '출결 누계를 다시 계산하여 확인하세요');
                errors.push(error);
            }
        }
        const individualRecords = this.attendanceRecords.get(studentId) || [];
        if (individualRecords.length > 0) {
            const recordCounts = this.countRecordsByType(individualRecords);
            if (summary.absenceDays > 0 && recordCounts.결석 > 0) {
                if (Math.abs(summary.absenceDays - recordCounts.결석) > 1) {
                    const error = this.createError(`결석일수 요약(${summary.absenceDays}일)이 개별 결석 기록 수(${recordCounts.결석}일)와 일치하지 않음`, 'absence-count-mismatch', 'warning', `요약: ${summary.absenceDays}일, 기록: ${recordCounts.결석}일`, '결석일수 계산을 확인하세요');
                    errors.push(error);
                }
            }
            if (summary.tardyDays > 0 && recordCounts.지각 > 0) {
                if (Math.abs(summary.tardyDays - recordCounts.지각) > 1) {
                    const error = this.createError(`지각일수 요약(${summary.tardyDays}일)이 개별 지각 기록 수(${recordCounts.지각}일)와 일치하지 않음`, 'tardy-count-mismatch', 'warning', `요약: ${summary.tardyDays}일, 기록: ${recordCounts.지각}일`, '지각일수 계산을 확인하세요');
                    errors.push(error);
                }
            }
        }
        if (summary.totalSchoolDays > 300) {
            const error = this.createError(`수업일수(${summary.totalSchoolDays}일)가 비정상적으로 높음`, 'unrealistic-school-days', 'warning', `${summary.totalSchoolDays}일`, '수업일수를 확인하세요 (일반적으로 190-220일)');
            errors.push(error);
        }
        return errors;
    }
    countRecordsByType(records) {
        const counts = {
            '출석': 0, '결석': 0, '지각': 0, '조퇴': 0, '결과': 0
        };
        for (const record of records) {
            if (record.type && record.date) {
                counts[record.type] = (counts[record.type] || 0) + 1;
            }
        }
        return counts;
    }
    getAttendanceStats(studentId) {
        const records = this.attendanceRecords.get(studentId) || [];
        const uniqueDates = new Set(records.filter(r => r.date).map(r => r.date)).size;
        const typeDistribution = this.countRecordsByType(records);
        const summary = this.attendanceSummaries.get(studentId);
        return {
            recordCount: records.length,
            uniqueDates,
            typeDistribution,
            summary
        };
    }
    clearAttendanceData() {
        this.attendanceRecords.clear();
        this.attendanceSummaries.clear();
    }
    getOverallStats() {
        const totalStudents = this.attendanceRecords.size;
        const totalRecords = Array.from(this.attendanceRecords.values())
            .reduce((sum, records) => sum + records.length, 0);
        const avgRecordsPerStudent = totalStudents > 0 ? totalRecords / totalStudents : 0;
        return {
            totalStudents,
            totalRecords,
            avgRecordsPerStudent: Math.round(avgRecordsPerStudent * 100) / 100,
            mostCommonIssues: [
                'duplicate-attendance-date',
                'attendance-summary-mismatch',
                'multiple-attendance-same-date'
            ]
        };
    }
}
exports.AttendanceDuplicateValidator = AttendanceDuplicateValidator;
//# sourceMappingURL=AttendanceDuplicateValidator.js.map
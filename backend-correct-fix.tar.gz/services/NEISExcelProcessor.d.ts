export interface NEISStudentRecord {
    studentInfo: {
        name: string;
        studentNumber: string;
        class: string;
        grade: string;
        school: string;
        birthDate?: string;
        gender?: string;
    };
    sections: {
        학적사항?: NEISSectionData;
        출결상황?: NEISSectionData;
        수상경력?: NEISSectionData;
        자격증및인증취득상황?: NEISSectionData;
        창의적체험활동상황?: NEISSectionData;
        교과학습발달상황?: NEISSectionData;
        독서활동상황?: NEISSectionData;
        행동특성및종합의견?: NEISSectionData;
    };
    metadata: {
        recordType: 'NEIS';
        processingDate: Date;
        totalSections: number;
        totalDataCells: number;
    };
}
export interface NEISSectionData {
    title: string;
    startRow: number;
    endRow: number;
    data: string[][];
    headers: string[];
    contentRows: string[][];
}
export declare class NEISExcelProcessor {
    private readonly NEIS_STRUCTURE;
    processNEISFile(buffer: Buffer, fileName: string): Promise<NEISStudentRecord[]>;
    private worksheetToArray;
    private extractStudentRecords;
    private extractStudentInfo;
    private extractStudentInfoFromFixedPositions;
    private extractStudentInfoDynamically;
    private extractSections;
    private extractSection;
    private findSectionStart;
    private findSectionEnd;
    private isContentRow;
    private getCellValue;
    private countDataCells;
    static isNEISFormat(data: string[][]): boolean;
    private isNameIndicator;
    private isStudentNumberIndicator;
    private isClassIndicator;
    private isSchoolIndicator;
    private findAdjacentValue;
    private isIndicatorText;
    private isValidName;
    private isValidStudentNumber;
    private findStudentNameAlternatively;
    private looksLikeStandaloneName;
}
//# sourceMappingURL=NEISExcelProcessor.d.ts.map
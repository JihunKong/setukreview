export interface FileCategory {
    id: string;
    fileName: string;
    category: '출결상황' | '개인세부능력' | '인적사항' | '수상경력' | '창의적체험활동' | '독서활동' | '행동특성및종합의견' | '기타';
    confidence: number;
    uploadedAt: Date;
    status: 'pending' | 'processing' | 'completed' | 'failed';
    fileSize: number;
    validationId?: string;
    metadata?: {
        sheetCount: number;
        detectedKeywords: string[];
        suggestedAlternatives?: string[];
        buffer?: Buffer;
    };
}
export interface CategoryDetectionResult {
    category: FileCategory['category'];
    confidence: number;
    detectedKeywords: string[];
    sheetAnalysis: SheetAnalysis[];
    suggestedAlternatives: string[];
}
interface SheetAnalysis {
    sheetName: string;
    keywordMatches: KeywordMatch[];
    structureScore: number;
    contentType: 'data' | 'summary' | 'header' | 'unknown';
}
interface KeywordMatch {
    keyword: string;
    category: string;
    count: number;
    positions: string[];
    weight: number;
}
export declare class FileCategoryDetector {
    private readonly CATEGORY_PATTERNS;
    private readonly NEIS_STRUCTURE_INDICATORS;
    private readonly EXCLUDED_SHEET_NAMES;
    detectCategory(buffer: Buffer, fileName: string): Promise<CategoryDetectionResult>;
    private analyzeByFileName;
    private analyzeBySheetNames;
    private analyzeByContent;
    private analyzeByStructure;
    private combineAnalysisResults;
    private convertWorkbookToExcelData;
    private extractAllText;
    private detectStudentInfoPattern;
    private detectDatePatterns;
    static getCategoryTheme(category: FileCategory['category']): {
        color: string;
        icon: string;
        bgColor: string;
    };
}
export {};
//# sourceMappingURL=FileCategoryDetector.d.ts.map
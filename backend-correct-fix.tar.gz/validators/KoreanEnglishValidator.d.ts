import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export declare class KoreanEnglishValidator extends BaseValidator {
    private readonly allowedEnglishTerms;
    private readonly allowedEnglishPatterns;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private extractEnglishContent;
    private isAllowedEnglishUsage;
    private isForeignName;
    private isBookTitleOrPublication;
    private isTechnicalTerm;
    private suggestKoreanAlternative;
}
//# sourceMappingURL=KoreanEnglishValidator.d.ts.map
declare const router: import("express-serve-static-core").Router;
export { router as uploadRouter };
//# sourceMappingURL=upload.d.ts.map
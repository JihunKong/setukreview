import { ExcelData } from '../types/validation';
export declare class ExcelProcessor {
    processFile(buffer: Buffer, fileName: string): Promise<ExcelData>;
    private convertToGenericFormat;
    private detectNEISFormat;
    getCellReference(row: number, col: number): string;
    getColumnLetter(col: number): string;
    validateFileFormat(buffer: Buffer): boolean;
    getFileInfo(buffer: Buffer, fileName: string): {
        isValid: boolean;
        info?: any;
        error?: string;
    };
}
//# sourceMappingURL=ExcelProcessor.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationService = void 0;
const KoreanEnglishValidator_1 = require("../validators/KoreanEnglishValidator");
const InstitutionNameValidator_1 = require("../validators/InstitutionNameValidator");
const GrammarValidator_1 = require("../validators/GrammarValidator");
const FormatValidator_1 = require("../validators/FormatValidator");
const AIValidator_1 = require("../validators/AIValidator");
const DuplicateDetectionValidator_1 = require("../validators/DuplicateDetectionValidator");
const AttendanceDuplicateValidator_1 = require("../validators/AttendanceDuplicateValidator");
const CrossStudentDuplicateDetector_1 = require("../validators/CrossStudentDuplicateDetector");
class ValidationService {
    static validationResults = new Map();
    static activeValidations = new Set();
    static async validateData(validationId, excelData) {
        const result = this.getResult(validationId);
        if (!result) {
            throw new Error('Validation result not found');
        }
        this.activeValidations.add(validationId);
        result.status = 'processing';
        result.progress = 0;
        try {
            console.log(`🔍 Starting validation for ${validationId} (Format: ${excelData.format || 'generic'})`);
            if (excelData.format === 'neis' && excelData.neisData) {
                await this.validateNEISData(validationId, excelData);
            }
            else {
                await this.validateGenericData(validationId, excelData);
            }
        }
        catch (error) {
            console.error(`❌ Validation failed for ${validationId}:`, error);
            result.status = 'failed';
            const systemError = {
                id: `system-error-${Date.now()}`,
                type: 'ai_validation',
                severity: 'error',
                message: `System error: ${error instanceof Error ? error.message : 'Unknown error'}`,
                location: { sheet: 'System', row: 0, column: 'A', cell: 'A0' },
                originalText: '',
                rule: 'system-validation'
            };
            result.errors.push(systemError);
            result.summary.errorCount = result.errors.length;
        }
        finally {
            this.activeValidations.delete(validationId);
            this.storeResult(validationId, result);
        }
    }
    static async validateNEISData(validationId, excelData) {
        const result = this.getResult(validationId);
        const neisData = excelData.neisData;
        console.log(`👥 Validating NEIS data for ${neisData.students.length} students`);
        const duplicateDetector = new DuplicateDetectionValidator_1.DuplicateDetectionValidator();
        const attendanceValidator = new AttendanceDuplicateValidator_1.AttendanceDuplicateValidator();
        const crossStudentDetector = new CrossStudentDuplicateDetector_1.CrossStudentDuplicateDetector();
        const validators = [
            new KoreanEnglishValidator_1.KoreanEnglishValidator(),
            new InstitutionNameValidator_1.InstitutionNameValidator(),
            new GrammarValidator_1.GrammarValidator(),
            new FormatValidator_1.FormatValidator(),
            duplicateDetector,
            attendanceValidator,
            crossStudentDetector,
            new AIValidator_1.AIValidator()
        ];
        let checkedCells = 0;
        const totalCells = result.summary.totalCells;
        for (let studentIndex = 0; studentIndex < neisData.students.length; studentIndex++) {
            const student = neisData.students[studentIndex];
            const displayName = this.getDisplayName(student.studentInfo.name);
            console.log(`📚 Processing student: ${displayName} (${studentIndex + 1}/${neisData.students.length})`);
            for (const [sectionName, sectionData] of Object.entries(student.sections)) {
                if (!sectionData)
                    continue;
                console.log(`  📝 Validating section: ${sectionName}`);
                for (let rowIndex = 0; rowIndex < sectionData.contentRows.length; rowIndex++) {
                    const row = sectionData.contentRows[rowIndex];
                    if (!this.activeValidations.has(validationId)) {
                        result.status = 'failed';
                        return;
                    }
                    for (let colIndex = 0; colIndex < row.length; colIndex++) {
                        const cellValue = row[colIndex];
                        if (!cellValue || cellValue.toString().trim() === '') {
                            continue;
                        }
                        const cellText = cellValue.toString().trim();
                        const actualRow = sectionData.startRow + rowIndex + 2;
                        const cellRef = this.getCellReference(actualRow, colIndex);
                        const displayName = this.getDisplayName(student.studentInfo.name);
                        const context = {
                            sheet: `${displayName}_${sectionName}`,
                            row: actualRow + 1,
                            column: this.getColumnLetter(colIndex),
                            cell: cellRef,
                            studentName: displayName,
                            section: sectionName,
                            adjacentCells: this.getAdjacentCellsFromArray(row, rowIndex, colIndex),
                            neisContext: {
                                studentInfo: student.studentInfo,
                                sectionName,
                                sectionType: sectionName,
                                isHeaderRow: false,
                                isContentRow: true
                            }
                        };
                        for (const validator of validators) {
                            try {
                                const errors = await validator.validate(cellText, context);
                                if (errors && errors.length > 0) {
                                    errors.forEach(error => {
                                        const displayName = this.getDisplayName(student.studentInfo.name);
                                        error.location = {
                                            sheet: `${displayName}_${sectionName}`,
                                            row: context.row,
                                            column: context.column,
                                            cell: context.cell
                                        };
                                        error.originalText = cellText;
                                        error.message = `[${displayName} - ${sectionName}] ${error.message}`;
                                        if (error.severity === 'error') {
                                            result.errors.push(error);
                                        }
                                        else if (error.severity === 'warning') {
                                            result.warnings.push(error);
                                        }
                                        else {
                                            result.info.push(error);
                                        }
                                    });
                                }
                            }
                            catch (validatorError) {
                                const displayName = this.getDisplayName(student.studentInfo.name);
                                console.error(`Validator error for ${displayName} ${sectionName} ${cellRef}:`, validatorError);
                            }
                        }
                        checkedCells++;
                        result.progress = Math.round((checkedCells / totalCells) * 100);
                        result.summary.checkedCells = checkedCells;
                        result.summary.errorCount = result.errors.length;
                        result.summary.warningCount = result.warnings.length;
                        result.summary.infoCount = result.info.length;
                        this.storeResult(validationId, result);
                        if (checkedCells % 50 === 0) {
                            await new Promise(resolve => setTimeout(resolve, 1));
                        }
                    }
                }
            }
        }
        result.status = 'completed';
        result.progress = 100;
        result.completedAt = new Date();
        console.log(`✅ NEIS validation completed for ${validationId}`);
        console.log(`   Students: ${neisData.students.length}, Errors: ${result.errors.length}, Warnings: ${result.warnings.length}, Info: ${result.info.length}`);
    }
    static async validateGenericData(validationId, excelData) {
        const result = this.getResult(validationId);
        console.log(`📊 Starting generic validation for ${validationId}`);
        const validators = [
            new KoreanEnglishValidator_1.KoreanEnglishValidator(),
            new InstitutionNameValidator_1.InstitutionNameValidator(),
            new GrammarValidator_1.GrammarValidator(),
            new FormatValidator_1.FormatValidator(),
            new AIValidator_1.AIValidator()
        ];
        let checkedCells = 0;
        const totalCells = result.summary.totalCells;
        for (const [sheetName, sheet] of Object.entries(excelData.sheets)) {
            console.log(`📋 Processing sheet: ${sheetName}`);
            const { data } = sheet;
            for (let row = 0; row < data.length; row++) {
                if (!this.activeValidations.has(validationId)) {
                    result.status = 'failed';
                    return;
                }
                for (let col = 0; col < data[row].length; col++) {
                    const cellValue = data[row][col];
                    if (!cellValue || cellValue.toString().trim() === '') {
                        continue;
                    }
                    const cellText = cellValue.toString().trim();
                    const cellRef = this.getCellReference(row, col);
                    const context = {
                        sheet: sheetName,
                        row: row + 1,
                        column: this.getColumnLetter(col),
                        cell: cellRef,
                        adjacentCells: this.getAdjacentCells(data, row, col)
                    };
                    for (const validator of validators) {
                        try {
                            const errors = await validator.validate(cellText, context);
                            if (errors && errors.length > 0) {
                                errors.forEach(error => {
                                    error.location = {
                                        sheet: sheetName,
                                        row: context.row,
                                        column: context.column,
                                        cell: context.cell
                                    };
                                    error.originalText = cellText;
                                    if (error.severity === 'error') {
                                        result.errors.push(error);
                                    }
                                    else if (error.severity === 'warning') {
                                        result.warnings.push(error);
                                    }
                                    else {
                                        result.info.push(error);
                                    }
                                });
                            }
                        }
                        catch (validatorError) {
                            console.error(`Validator error for cell ${cellRef}:`, validatorError);
                        }
                    }
                    checkedCells++;
                    result.progress = Math.round((checkedCells / totalCells) * 100);
                    result.summary.checkedCells = checkedCells;
                    result.summary.errorCount = result.errors.length;
                    result.summary.warningCount = result.warnings.length;
                    result.summary.infoCount = result.info.length;
                    this.storeResult(validationId, result);
                    if (checkedCells % 100 === 0) {
                        await new Promise(resolve => setTimeout(resolve, 1));
                    }
                }
            }
        }
        result.status = 'completed';
        result.progress = 100;
        result.completedAt = new Date();
        console.log(`✅ Generic validation completed for ${validationId}`);
        console.log(`   Errors: ${result.errors.length}, Warnings: ${result.warnings.length}, Info: ${result.info.length}`);
    }
    static storeResult(validationId, result) {
        this.validationResults.set(validationId, result);
    }
    static getResult(validationId) {
        return this.validationResults.get(validationId);
    }
    static cancelValidation(validationId) {
        this.activeValidations.delete(validationId);
        const result = this.getResult(validationId);
        if (result && result.status === 'processing') {
            result.status = 'failed';
            this.storeResult(validationId, result);
        }
    }
    static getRecentValidations(limit = 10) {
        const results = Array.from(this.validationResults.values())
            .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
            .slice(0, limit);
        return results;
    }
    static cleanup() {
        const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
        for (const [id, result] of this.validationResults.entries()) {
            if (result.createdAt < oneDayAgo) {
                this.validationResults.delete(id);
            }
        }
    }
    static getCellReference(row, col) {
        const columnLetter = this.getColumnLetter(col);
        return `${columnLetter}${row + 1}`;
    }
    static getColumnLetter(col) {
        let letter = '';
        while (col >= 0) {
            letter = String.fromCharCode(col % 26 + 65) + letter;
            col = Math.floor(col / 26) - 1;
        }
        return letter;
    }
    static getAdjacentCells(data, row, col) {
        return {
            left: col > 0 ? data[row][col - 1]?.toString() : undefined,
            right: col < data[row].length - 1 ? data[row][col + 1]?.toString() : undefined,
            above: row > 0 ? data[row - 1][col]?.toString() : undefined,
            below: row < data.length - 1 ? data[row + 1][col]?.toString() : undefined,
        };
    }
    static getAdjacentCellsFromArray(rowData, rowIndex, colIndex) {
        return {
            left: colIndex > 0 ? rowData[colIndex - 1]?.toString() : undefined,
            right: colIndex < rowData.length - 1 ? rowData[colIndex + 1]?.toString() : undefined,
            above: undefined,
            below: undefined,
        };
    }
    static getDisplayName(studentName) {
        if (!studentName || studentName.trim() === '') {
            return '학생정보_없음';
        }
        const name = studentName.trim();
        if (name === '학생정보_미확인') {
            return '학생정보_미확인';
        }
        if (name === '미상') {
            return '학생정보_미상';
        }
        return name;
    }
}
exports.ValidationService = ValidationService;
setInterval(() => {
    ValidationService.cleanup();
}, 60 * 60 * 1000);
//# sourceMappingURL=ValidationService.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SelectiveValidationService = void 0;
const ValidationService_1 = require("./ValidationService");
const SessionManager_1 = require("./SessionManager");
const ExcelProcessor_1 = require("./ExcelProcessor");
const uuid_1 = require("uuid");
class SelectiveValidationService {
    static instance;
    sessionManager;
    batchValidations = new Map();
    activeBatches = new Set();
    constructor() {
        this.sessionManager = SessionManager_1.SessionManager.getInstance();
    }
    static getInstance() {
        if (!SelectiveValidationService.instance) {
            SelectiveValidationService.instance = new SelectiveValidationService();
        }
        return SelectiveValidationService.instance;
    }
    async startBatchValidation(sessionId, options) {
        const session = this.sessionManager.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        const filesToValidate = this.getFilesToValidate(sessionId, options);
        if (filesToValidate.length === 0) {
            throw new Error('No files selected for validation');
        }
        const batchId = (0, uuid_1.v4)();
        const batchResult = {
            batchId,
            sessionId,
            status: 'pending',
            progress: 0,
            startedAt: new Date(),
            results: new Map(),
            summary: {
                totalFiles: filesToValidate.length,
                completedFiles: 0,
                failedFiles: 0,
                totalErrors: 0,
                totalWarnings: 0,
                totalInfo: 0,
                processingTimeSeconds: 0
            },
            options
        };
        this.batchValidations.set(batchId, batchResult);
        this.activeBatches.add(batchId);
        console.log(`🚀 Starting batch validation ${batchId} for ${filesToValidate.length} files`);
        this.processBatchValidation(batchId, filesToValidate)
            .catch(error => {
            console.error(`Batch validation failed for ${batchId}:`, error);
            const batch = this.batchValidations.get(batchId);
            if (batch) {
                batch.status = 'failed';
                batch.completedAt = new Date();
            }
        })
            .finally(() => {
            this.activeBatches.delete(batchId);
        });
        return batchId;
    }
    async validateCategory(sessionId, category, options = {}) {
        return this.startBatchValidation(sessionId, {
            ...options,
            validateAll: false,
            selectedCategories: [category]
        });
    }
    async validateAll(sessionId, options = {}) {
        return this.startBatchValidation(sessionId, {
            ...options,
            validateAll: true
        });
    }
    async validateAllFilesSync(sessionId) {
        const session = this.sessionManager.getSession(sessionId);
        if (!session) {
            throw new Error('Session not found');
        }
        const allFiles = this.sessionManager.getSessionFiles(sessionId);
        if (allFiles.length === 0) {
            throw new Error('No files found in session');
        }
        console.log(`🚀 Starting synchronous validation for ${allFiles.length} files in session ${sessionId}`);
        const results = [];
        const validationPromises = allFiles.map(async (file) => {
            try {
                console.log(`🔍 Validating file: ${file.fileName}`);
                return await this.validateSingleFileSync(file);
            }
            catch (error) {
                console.error(`❌ Validation failed for ${file.fileName}:`, error);
                return {
                    id: file.id,
                    fileName: file.fileName,
                    status: 'failed',
                    progress: 100,
                    errors: [{
                            id: (0, uuid_1.v4)(),
                            type: 'ai_validation',
                            severity: 'error',
                            message: error instanceof Error ? error.message : 'Validation failed',
                            location: { sheet: 'unknown', cell: 'N/A', row: 0, column: 'N/A' },
                            originalText: '',
                            rule: 'System validation error',
                            confidence: 1.0,
                            suggestion: 'Please check the file format and try again'
                        }],
                    warnings: [],
                    info: [],
                    summary: {
                        totalCells: 0,
                        checkedCells: 0,
                        errorCount: 1,
                        warningCount: 0,
                        infoCount: 0
                    },
                    createdAt: new Date(),
                    completedAt: new Date()
                };
            }
        });
        const validationResults = await Promise.allSettled(validationPromises);
        for (const result of validationResults) {
            if (result.status === 'fulfilled' && result.value) {
                results.push(result.value);
            }
            else {
                console.error('Failed to process validation result:', result);
            }
        }
        console.log(`✅ Synchronous validation completed for session ${sessionId}. Results: ${results.length} files`);
        return results;
    }
    getBatchResult(batchId) {
        return this.batchValidations.get(batchId) || null;
    }
    cancelBatchValidation(batchId) {
        const batch = this.batchValidations.get(batchId);
        if (!batch || batch.status === 'completed' || batch.status === 'failed') {
            return false;
        }
        batch.status = 'cancelled';
        batch.completedAt = new Date();
        this.activeBatches.delete(batchId);
        console.log(`❌ Cancelled batch validation: ${batchId}`);
        return true;
    }
    getSessionBatches(sessionId) {
        return Array.from(this.batchValidations.values())
            .filter(batch => batch.sessionId === sessionId)
            .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
    }
    async processBatchValidation(batchId, files) {
        const batch = this.batchValidations.get(batchId);
        if (!batch) {
            throw new Error('Batch validation not found');
        }
        batch.status = 'processing';
        const startTime = Date.now();
        let completedFiles = 0;
        try {
            const maxConcurrency = batch.options.maxConcurrency || 3;
            const chunks = this.chunkArray(files, maxConcurrency);
            for (const chunk of chunks) {
                const currentBatch = this.batchValidations.get(batchId);
                if (!currentBatch || currentBatch.status === 'cancelled') {
                    break;
                }
                const chunkPromises = chunk.map(async (file) => {
                    const currentBatch = this.batchValidations.get(batchId);
                    if (!currentBatch || currentBatch.status === 'cancelled') {
                        return { success: false, file, error: 'Cancelled' };
                    }
                    try {
                        await this.validateSingleFile(batchId, file);
                        return { success: true, file };
                    }
                    catch (error) {
                        console.error(`Validation failed for file ${file.fileName}:`, error);
                        return { success: false, file, error };
                    }
                });
                const chunkResults = await Promise.allSettled(chunkPromises);
                for (const result of chunkResults) {
                    if (result.status === 'fulfilled' && result.value) {
                        if (result.value.success) {
                            completedFiles++;
                        }
                        else {
                            batch.summary.failedFiles++;
                            console.error(`File ${result.value.file.fileName} failed:`, result.value.error);
                        }
                    }
                    else {
                        batch.summary.failedFiles++;
                        console.error(`Chunk processing failed:`, result.status === 'rejected' ? result.reason : 'Unknown error');
                    }
                    batch.progress = Math.round((completedFiles + batch.summary.failedFiles) / files.length * 100);
                    batch.summary.completedFiles = completedFiles;
                    const processedFiles = completedFiles + batch.summary.failedFiles;
                    if (processedFiles > 0) {
                        const elapsedSeconds = (Date.now() - startTime) / 1000;
                        const avgTimePerFile = elapsedSeconds / processedFiles;
                        const remainingFiles = files.length - processedFiles;
                        const estimatedRemainingSeconds = remainingFiles * avgTimePerFile;
                        batch.estimatedCompletionTime = new Date(Date.now() + estimatedRemainingSeconds * 1000);
                    }
                }
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            const finalBatch = this.batchValidations.get(batchId);
            if (finalBatch && finalBatch.status !== 'cancelled') {
                finalBatch.status = 'completed';
                finalBatch.progress = 100;
            }
            batch.completedAt = new Date();
            batch.summary.processingTimeSeconds = (Date.now() - startTime) / 1000;
            console.log(`✅ Batch validation completed: ${batchId} (${batch.summary.processingTimeSeconds}s)`);
            console.log(`   Completed: ${completedFiles}, Failed: ${batch.summary.failedFiles}, Total: ${files.length}`);
        }
        catch (error) {
            console.error(`Batch validation error for ${batchId}:`, error);
            batch.status = 'failed';
            batch.completedAt = new Date();
            batch.summary.processingTimeSeconds = (Date.now() - startTime) / 1000;
        }
    }
    async validateSingleFile(batchId, file) {
        const batch = this.batchValidations.get(batchId);
        if (!batch) {
            throw new Error('Batch validation not found');
        }
        this.sessionManager.updateFileStatus(batch.sessionId, file.id, 'processing');
        try {
            console.log(`🔍 Validating file: ${file.fileName}`);
            const buffer = file.metadata?.buffer;
            if (!buffer) {
                throw new Error(`No buffer found for file: ${file.fileName}`);
            }
            const validationResult = await this.validateFileContent(file.fileName, buffer);
            batch.results.set(file.id, validationResult);
            this.sessionManager.addValidationResult(batch.sessionId, file.id, validationResult);
            batch.summary.totalErrors += validationResult.errors.length;
            batch.summary.totalWarnings += validationResult.warnings.length;
            batch.summary.totalInfo += validationResult.info.length;
            this.sessionManager.updateFileStatus(batch.sessionId, file.id, validationResult.status === 'completed' ? 'completed' : 'failed');
        }
        catch (error) {
            console.error(`❌ Error validating file ${file.fileName}:`, error);
            this.sessionManager.updateFileStatus(batch.sessionId, file.id, 'failed');
            throw error;
        }
    }
    async validateSingleFileSync(file) {
        try {
            console.log(`🔍 Starting synchronous validation for: ${file.fileName}`);
            const buffer = file.metadata?.buffer;
            if (!buffer) {
                throw new Error(`No buffer found for file: ${file.fileName}`);
            }
            const validationResult = await this.validateFileContent(file.fileName, buffer);
            validationResult.fileId = file.id;
            console.log(`🔍 STORING validation result ${validationResult.id} in ValidationService`);
            ValidationService_1.ValidationService.storeResult(validationResult.id, validationResult);
            const stored = ValidationService_1.ValidationService.getResult(validationResult.id);
            console.log(`✅ Verification: stored result exists = ${!!stored}`);
            console.log(`✅ Synchronous validation completed for: ${file.fileName}`);
            console.log(`   Errors: ${validationResult.errors.length}, Warnings: ${validationResult.warnings.length}, Info: ${validationResult.info.length}`);
            return validationResult;
        }
        catch (error) {
            console.error(`❌ Synchronous validation failed for ${file.fileName}:`, error);
            throw error;
        }
    }
    async validateFileContent(fileName, buffer) {
        try {
            const validationId = (0, uuid_1.v4)();
            const validationResult = {
                id: validationId,
                fileName,
                status: 'processing',
                progress: 0,
                createdAt: new Date(),
                summary: {
                    totalCells: 0,
                    checkedCells: 0,
                    errorCount: 0,
                    warningCount: 0,
                    infoCount: 0
                },
                errors: [],
                warnings: [],
                info: []
            };
            ValidationService_1.ValidationService.storeResult(validationId, validationResult);
            const excelProcessor = new ExcelProcessor_1.ExcelProcessor();
            const excelData = await excelProcessor.processFile(buffer, fileName);
            let totalCells = 0;
            if (excelData.neisData && excelData.format === 'neis') {
                for (const student of excelData.neisData.students) {
                    for (const [sectionName, sectionData] of Object.entries(student.sections)) {
                        if (sectionData) {
                            totalCells += sectionData.contentRows.reduce((sum, row) => sum + row.length, 0);
                        }
                    }
                }
            }
            else {
                for (const sheet of Object.values(excelData.sheets)) {
                    totalCells += sheet.data.reduce((sum, row) => sum + row.length, 0);
                }
            }
            validationResult.summary.totalCells = totalCells;
            ValidationService_1.ValidationService.storeResult(validationId, validationResult);
            await ValidationService_1.ValidationService.validateData(validationId, excelData);
            const finalResult = ValidationService_1.ValidationService.getResult(validationId);
            if (!finalResult) {
                throw new Error('Validation result not found after processing');
            }
            return finalResult;
        }
        catch (error) {
            console.error(`File validation error for ${fileName}:`, error);
            return {
                id: (0, uuid_1.v4)(),
                fileName,
                status: 'failed',
                progress: 0,
                createdAt: new Date(),
                summary: {
                    totalCells: 0,
                    checkedCells: 0,
                    errorCount: 1,
                    warningCount: 0,
                    infoCount: 0
                },
                errors: [{
                        id: `system-error-${Date.now()}`,
                        type: 'ai_validation',
                        severity: 'error',
                        message: `File processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
                        location: { sheet: 'System', row: 0, column: 'A', cell: 'A0' },
                        originalText: '',
                        rule: 'system-validation'
                    }],
                warnings: [],
                info: []
            };
        }
    }
    getFilesToValidate(sessionId, options) {
        let files = [];
        if (options.validateAll) {
            files = this.sessionManager.getSessionFiles(sessionId);
        }
        else if (options.selectedFileIds && options.selectedFileIds.length > 0) {
            const allFiles = this.sessionManager.getSessionFiles(sessionId);
            files = allFiles.filter(file => options.selectedFileIds.includes(file.id));
        }
        else if (options.selectedCategories && options.selectedCategories.length > 0) {
            for (const category of options.selectedCategories) {
                const categoryFiles = this.sessionManager.getFilesByCategory(sessionId, category);
                files.push(...categoryFiles);
            }
        }
        return files.filter(file => file.status === 'pending' ||
            file.status === 'failed' ||
            file.status === 'completed');
    }
    chunkArray(array, chunkSize) {
        const chunks = [];
        for (let i = 0; i < array.length; i += chunkSize) {
            chunks.push(array.slice(i, i + chunkSize));
        }
        return chunks;
    }
    getCategoryValidationStats(batchId) {
        const batch = this.batchValidations.get(batchId);
        if (!batch) {
            return {};
        }
        const files = this.sessionManager.getSessionFiles(batch.sessionId);
        const stats = {};
        files.forEach(file => {
            const result = batch.results.get(file.id);
            if (!stats[file.category]) {
                stats[file.category] = {
                    totalFiles: 0,
                    completedFiles: 0,
                    totalErrors: 0,
                    totalWarnings: 0
                };
            }
            stats[file.category].totalFiles++;
            if (result) {
                stats[file.category].completedFiles++;
                stats[file.category].totalErrors += result.errors.length;
                stats[file.category].totalWarnings += result.warnings.length;
            }
        });
        Object.keys(stats).forEach(category => {
            const categoryStats = stats[category];
            categoryStats.avgErrorsPerFile = categoryStats.completedFiles > 0
                ? Math.round((categoryStats.totalErrors / categoryStats.completedFiles) * 100) / 100
                : 0;
            categoryStats.avgWarningsPerFile = categoryStats.completedFiles > 0
                ? Math.round((categoryStats.totalWarnings / categoryStats.completedFiles) * 100) / 100
                : 0;
        });
        return stats;
    }
    cleanupOldBatches(maxAgeHours = 24) {
        const cutoffTime = Date.now() - (maxAgeHours * 60 * 60 * 1000);
        const batchesToDelete = [];
        for (const [batchId, batch] of this.batchValidations.entries()) {
            if (batch.completedAt && batch.completedAt.getTime() < cutoffTime) {
                batchesToDelete.push(batchId);
            }
        }
        batchesToDelete.forEach(batchId => {
            this.batchValidations.delete(batchId);
        });
        if (batchesToDelete.length > 0) {
            console.log(`🧹 Cleaned up ${batchesToDelete.length} old batch validations`);
        }
    }
    getServiceStats() {
        const batches = Array.from(this.batchValidations.values());
        return {
            totalBatches: batches.length,
            activeBatches: this.activeBatches.size,
            completedBatches: batches.filter(b => b.status === 'completed').length,
            failedBatches: batches.filter(b => b.status === 'failed').length,
            totalFilesProcessed: batches.reduce((sum, b) => sum + b.summary.completedFiles, 0),
            avgProcessingTimePerFile: this.calculateAvgProcessingTime(batches)
        };
    }
    calculateAvgProcessingTime(batches) {
        const completedBatches = batches.filter(b => b.status === 'completed');
        if (completedBatches.length === 0)
            return 0;
        const totalTime = completedBatches.reduce((sum, b) => sum + b.summary.processingTimeSeconds, 0);
        const totalFiles = completedBatches.reduce((sum, b) => sum + b.summary.completedFiles, 0);
        return totalFiles > 0 ? Math.round((totalTime / totalFiles) * 100) / 100 : 0;
    }
}
exports.SelectiveValidationService = SelectiveValidationService;
//# sourceMappingURL=SelectiveValidationService.js.map
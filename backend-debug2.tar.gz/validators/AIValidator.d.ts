import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export declare class AIValidator extends BaseValidator {
    private openai;
    private readonly enabled;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private performAIValidation;
    private buildValidationPrompt;
    private parseAIResponse;
    private mapSeverity;
}
//# sourceMappingURL=AIValidator.d.ts.map
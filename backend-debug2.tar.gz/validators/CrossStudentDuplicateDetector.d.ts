import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
import { SimilarityResult } from './DuplicateDetectionValidator';
export interface GlobalTextEntry {
    id: string;
    studentName: string;
    section: string;
    location: string;
    text: string;
    hash: string;
    wordCount: number;
    createdAt: Date;
    metadata?: {
        isTemplate?: boolean;
        frequency?: number;
        commonPhrases?: string[];
    };
}
export interface CrossStudentMatch {
    similarity: SimilarityResult;
    sourceEntry: GlobalTextEntry;
    matchType: 'exact' | 'high_similarity' | 'partial' | 'template';
    affectedStudents: string[];
}
export declare class CrossStudentDuplicateDetector extends BaseValidator {
    private globalTextCorpus;
    private duplicateDetector;
    private processedTexts;
    private readonly CROSS_STUDENT_THRESHOLDS;
    private readonly SECTION_RULES;
    constructor();
    validate(text: string, context: ValidationContext): Promise<ValidationError[]>;
    private shouldCheckCrossStudent;
    private findCrossStudentMatches;
    private calculateDetailedSimilarity;
    private getRelevantCorpusEntries;
    private areSectionsRelated;
    private determineMatchType;
    private findAffectedStudents;
    private determineCrossStudentSeverity;
    private createCrossStudentError;
    private getMatchTypeText;
    private getCrossStudentSuggestion;
    private addToCorpus;
    private getSectionKey;
    private generateTextHash;
    private performCorpusCleanup;
    getCorpusStatistics(): {
        totalEntries: number;
        sectionsCount: number;
        studentsCount: number;
        avgEntriesPerSection: number;
        avgEntriesPerStudent: number;
        sectionDistribution: Record<string, number>;
        riskLevelDistribution: Record<string, number>;
    };
    clearCorpus(): void;
}
//# sourceMappingURL=CrossStudentDuplicateDetector.d.ts.map
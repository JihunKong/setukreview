import { BaseValidator } from './BaseValidator';
import { ValidationError, ValidationContext } from '../types/validation';
export declare class FormatValidator extends BaseValidator {
    private readonly prohibitedSpecialChars;
    private readonly allowedSpecialChars;
    constructor();
    validate(text: string, _context: ValidationContext): Promise<ValidationError[]>;
    private checkSpecialCharacters;
    private checkQuotationMarks;
    private checkMismatchedQuotes;
    private checkBracketConsistency;
    private getCharacterDescription;
    private getSuggestionForChar;
    private checkPunctuationRepetition;
    private getPunctuationSuggestion;
}
//# sourceMappingURL=FormatValidator.d.ts.map
declare const router: import("express-serve-static-core").Router;
export { router as validationRouter };
//# sourceMappingURL=validation.d.ts.map
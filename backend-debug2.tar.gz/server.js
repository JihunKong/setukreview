"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const upload_1 = require("./routes/upload");
const validation_1 = require("./routes/validation");
const report_1 = require("./routes/report");
const app = (0, express_1.default)();
const PORT = parseInt(process.env.PORT || (process.env.NODE_ENV === 'production' ? '8080' : '3001'), 10);
app.set('trust proxy', true);
app.use((0, helmet_1.default)({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
}));
const createRateLimiter = (options) => {
    return (0, express_rate_limit_1.default)({
        ...options,
        handler: (req, res) => {
            const origin = req.headers.origin;
            if (origin && (origin.includes('.up.railway.app') || origin.includes('localhost') || process.env.NODE_ENV !== 'production')) {
                res.setHeader('Access-Control-Allow-Origin', origin);
                res.setHeader('Access-Control-Allow-Credentials', 'true');
                res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
                res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
            }
            res.status(429).json({
                error: 'Too Many Requests',
                message: options.message || 'Too many requests from this IP, please try again later.',
                retryAfter: Math.ceil(options.windowMs / 1000)
            });
        }
    });
};
const generalLimiter = createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 500,
    message: 'Too many requests from this IP, please try again later.',
});
const validationLimiter = createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 1000,
    message: 'Too many validation requests, please slow down.',
});
const uploadLimiter = createRateLimiter({
    windowMs: 5 * 60 * 1000,
    max: 20,
    message: 'Too many file uploads, please try again later.',
});
app.use(generalLimiter);
app.use((0, compression_1.default)());
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        if (!origin)
            return callback(null, true);
        const allowedOrigins = [
            'https://setukreview-frontend-production.up.railway.app',
            'https://setukreview-backend-production.up.railway.app',
            'http://localhost:3000',
            'http://localhost:3001',
            'http://localhost:8080'
        ];
        if (process.env.NODE_ENV === 'production') {
            if (allowedOrigins.includes(origin) || origin.includes('.up.railway.app')) {
                callback(null, true);
            }
            else {
                console.warn(`CORS blocked origin: ${origin}`);
                callback(null, false);
            }
        }
        else {
            callback(null, true);
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Content-Length', 'X-Foo', 'X-Bar'],
    optionsSuccessStatus: 200
}));
app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
        const allowedOrigins = [
            'https://setukreview-frontend-production.up.railway.app',
            'https://setukreview-backend-production.up.railway.app',
            'http://localhost:3000',
            'http://localhost:3001',
            'http://localhost:8080'
        ];
        if (allowedOrigins.includes(origin) || origin.includes('.up.railway.app') || process.env.NODE_ENV !== 'production') {
            res.setHeader('Access-Control-Allow-Origin', origin);
            res.setHeader('Access-Control-Allow-Credentials', 'true');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
        }
    }
    next();
});
app.use(express_1.default.json({ limit: '1mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '1mb' }));
app.use('/api/upload', uploadLimiter, upload_1.uploadRouter);
app.use('/api/validation', validationLimiter, validation_1.validationRouter);
app.use('/api/report', report_1.reportRouter);
app.get('/api/health', (_req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});
app.use('*', (req, res) => {
    const origin = req.headers.origin;
    if (origin && (origin.includes('.up.railway.app') || origin.includes('localhost') || process.env.NODE_ENV !== 'production')) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
    }
    res.status(404).json({ error: 'Not Found' });
});
app.use((err, req, res, _next) => {
    console.error('Server Error:', err);
    const origin = req.headers.origin;
    if (origin && (origin.includes('.up.railway.app') || origin.includes('localhost') || process.env.NODE_ENV !== 'production')) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
    }
    res.status(500).json({
        error: process.env.NODE_ENV === 'production'
            ? 'Internal Server Error'
            : err.message
    });
});
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});
process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    process.exit(0);
});
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📝 API documentation available at http://localhost:${PORT}/api/health`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});
exports.default = app;
//# sourceMappingURL=server.js.map